/**
 * BIO-CLINIC CLINICAL KNOWLEDGE DATABASE
 * =====================================
 * Version: 3.0.0
 * Generated: 2026-01-28T13:09:23.968488
 * 
 * Questo è il GRAFO DI CONOSCENZA CLINICA più avanzato
 * per un sito statico. Include:
 * - 1136 esami con categorizzazione AI
 * - Tagging sintomatico per ricerca naturale
 * - Sistema di upselling pack-first
 * - Logica di urgenza e prenotazione
 * 
 * © Bio-Clinic Sassari - bio-clinic.it
 */

const BioClinicDB = (function() {
  'use strict';

  // =============================================
  // 1. PACCHETTI CHECK-UP (PACK-FIRST STRATEGY)
  // =============================================
  const pacchetti = [
    {
        "id": "base",
        "nome": "Check Up Base",
        "prezzo": 55.0,
        "descrizione": "Controllo annuale essenziale per tutti",
        "target": [
            "tutti",
            "prevenzione"
        ],
        "tags": [
            "prevenzione",
            "controllo annuale",
            "base"
        ],
        "esami_chiave": [
            "emocromo",
            "got",
            "gpt",
            "gamma-gt",
            "trigliceridi",
            "colesterolo-totale",
            "colesterolo-hdl",
            "colesterolo-ldl",
            "glucosio",
            "creatinina",
            "uricemia",
            "sodio",
            "elettroforesi",
            "urine",
            "tas",
            "ferritina",
            "acido-folico",
            "tsh"
        ],
        "esami_count": 18,
        "risparmio": "Risparmi il 40% rispetto agli esami singoli",
        "icona": "🩺"
    },
    {
        "id": "donna-under40",
        "nome": "Check Up Donna Under 40",
        "prezzo": 97.0,
        "descrizione": "Screening completo per donne giovani con focus su ferro e vitamine",
        "target": [
            "donna",
            "under40"
        ],
        "tags": [
            "donna",
            "prevenzione",
            "fertilità",
            "energia"
        ],
        "esami_chiave": [
            "emocromo",
            "got",
            "gpt",
            "gamma-gt",
            "trigliceridi",
            "colesterolo-totale",
            "hdl",
            "ldl",
            "glucosio",
            "creatinina",
            "uricemia",
            "sodio",
            "sideremia",
            "ferritina",
            "vitamina-d",
            "acido-folico",
            "tsh"
        ],
        "esami_count": 17,
        "risparmio": "Risparmi il 35% rispetto agli esami singoli",
        "icona": "👩"
    },
    {
        "id": "donna-over40",
        "nome": "Check Up Donna Over 40",
        "prezzo": 75.0,
        "descrizione": "Screening completo con focus su tiroide, ossa e ormoni",
        "target": [
            "donna",
            "over40",
            "menopausa"
        ],
        "tags": [
            "donna",
            "menopausa",
            "tiroide",
            "ossa"
        ],
        "esami_chiave": [
            "emocromo",
            "got",
            "gpt",
            "gamma-gt",
            "trigliceridi",
            "colesterolo-totale",
            "hdl",
            "ldl",
            "glucosio",
            "creatinina",
            "uricemia",
            "sodio",
            "t3",
            "t4",
            "tsh",
            "calcio",
            "elettroforesi",
            "estradiolo",
            "paratormone",
            "anti-tpo"
        ],
        "esami_count": 20,
        "risparmio": "Risparmi il 45% rispetto agli esami singoli",
        "icona": "👩‍🦳"
    },
    {
        "id": "uomo-under40",
        "nome": "Check Up Uomo Under 40",
        "prezzo": 75.0,
        "descrizione": "Controllo completo per uomini giovani con PSA",
        "target": [
            "uomo",
            "under40"
        ],
        "tags": [
            "uomo",
            "prostata",
            "prevenzione"
        ],
        "esami_chiave": [
            "emocromo",
            "got",
            "gpt",
            "gamma-gt",
            "trigliceridi",
            "colesterolo-totale",
            "hdl",
            "ldl",
            "glucosio",
            "creatinina",
            "uricemia",
            "sodio",
            "testosterone",
            "psa-totale"
        ],
        "esami_count": 14,
        "risparmio": "Risparmi il 30% rispetto agli esami singoli",
        "icona": "👨"
    },
    {
        "id": "uomo-over40",
        "nome": "Check Up Uomo Over 40",
        "prezzo": 124.99,
        "descrizione": "Screening approfondito con PSA libero e vitamina D",
        "target": [
            "uomo",
            "over40",
            "prostata"
        ],
        "tags": [
            "uomo",
            "prostata",
            "prevenzione",
            "completo"
        ],
        "esami_chiave": [
            "emocromo",
            "got",
            "gpt",
            "gamma-gt",
            "trigliceridi",
            "colesterolo-totale",
            "hdl",
            "ldl",
            "glucosio",
            "creatinina",
            "uricemia",
            "sodio",
            "psa-totale",
            "psa-libero",
            "elettroforesi",
            "vitamina-d",
            "tsh"
        ],
        "esami_count": 17,
        "risparmio": "Risparmi il 35% rispetto agli esami singoli",
        "icona": "👨‍🦳"
    },
    {
        "id": "bambino",
        "nome": "Check Up Bambino",
        "prezzo": 59.9,
        "descrizione": "Controllo pediatrico essenziale",
        "target": [
            "bambino",
            "pediatrico"
        ],
        "tags": [
            "bambino",
            "pediatrico",
            "crescita"
        ],
        "esami_chiave": [
            "emocromo",
            "azotemia",
            "creatinina",
            "trigliceridi",
            "colesterolo-totale",
            "glucosio",
            "calcio",
            "vitamina-d"
        ],
        "esami_count": 8,
        "risparmio": "Risparmi il 25% rispetto agli esami singoli",
        "icona": "👶"
    },
    {
        "id": "tiroide-base",
        "nome": "Check Up Tiroide Base",
        "prezzo": 29.0,
        "descrizione": "Screening essenziale della funzionalità tiroidea",
        "target": [
            "tiroide",
            "screening"
        ],
        "tags": [
            "tiroide",
            "stanchezza",
            "peso"
        ],
        "esami_chiave": [
            "tsh",
            "ft3",
            "ft4"
        ],
        "esami_count": 3,
        "risparmio": "Pacchetto base tiroide",
        "icona": "🦋"
    },
    {
        "id": "tiroide-plus",
        "nome": "Check Up Tiroide Plus",
        "prezzo": 85.9,
        "descrizione": "Valutazione completa tiroide con markers autoimmuni",
        "target": [
            "tiroide",
            "autoimmunità"
        ],
        "tags": [
            "tiroide",
            "hashimoto",
            "basedow",
            "anticorpi"
        ],
        "esami_chiave": [
            "emocromo",
            "calcio",
            "sodio",
            "tsh",
            "ft3",
            "ft4",
            "tireoglobulina",
            "ftqi",
            "calcitonina",
            "urine"
        ],
        "esami_count": 10,
        "risparmio": "Risparmi il 40% rispetto agli esami singoli",
        "icona": "🦋"
    },
    {
        "id": "cardio",
        "nome": "Check Up Cardiologico Plus",
        "prezzo": 125.0,
        "descrizione": "Profilo cardiovascolare completo con markers cardiaci",
        "target": [
            "cuore",
            "cardiovascolare"
        ],
        "tags": [
            "cuore",
            "colesterolo",
            "infarto",
            "prevenzione"
        ],
        "esami_chiave": [
            "emocromo",
            "got",
            "gpt",
            "gamma-gt",
            "trigliceridi",
            "colesterolo-totale",
            "hdl",
            "ldl",
            "glucosio",
            "creatinina",
            "uricemia",
            "sodio",
            "bilirubina-totale",
            "troponina-t",
            "bnp"
        ],
        "esami_count": 15,
        "risparmio": "Risparmi il 50% rispetto agli esami singoli",
        "icona": "❤️"
    },
    {
        "id": "renale",
        "nome": "Check Up Profilo Renale",
        "prezzo": 29.0,
        "descrizione": "Valutazione della funzionalità renale",
        "target": [
            "reni",
            "renale"
        ],
        "tags": [
            "reni",
            "creatinina",
            "funzionalità"
        ],
        "esami_chiave": [
            "azotemia",
            "creatinina",
            "urine"
        ],
        "esami_count": 3,
        "risparmio": "Pacchetto base reni",
        "icona": "💧"
    },
    {
        "id": "epatico",
        "nome": "Check Up Profilo Epatico",
        "prezzo": 75.0,
        "descrizione": "Valutazione completa della funzionalità epatica",
        "target": [
            "fegato",
            "epatico"
        ],
        "tags": [
            "fegato",
            "transaminasi",
            "epatite"
        ],
        "esami_chiave": [
            "emocromo",
            "got",
            "gpt",
            "gamma-gt",
            "bilirubina-totale",
            "bilirubina-diretta"
        ],
        "esami_count": 6,
        "risparmio": "Risparmi il 30% rispetto agli esami singoli",
        "icona": "🫁"
    },
    {
        "id": "pregravidanza",
        "nome": "Check Up Pre Gravidanza",
        "prezzo": 185.0,
        "descrizione": "Screening completo pre-concepimento",
        "target": [
            "gravidanza",
            "fertilità",
            "donna"
        ],
        "tags": [
            "gravidanza",
            "fertilità",
            "torch",
            "screening"
        ],
        "esami_chiave": [
            "emocromo",
            "test-gravidanza",
            "got",
            "gpt",
            "gamma-gt",
            "hcv",
            "hbsag",
            "hiv",
            "epatite-a",
            "toxoplasmosi",
            "citomegalovirus",
            "rosolia",
            "tsh",
            "ft3",
            "ft4",
            "ogtt",
            "urine"
        ],
        "esami_count": 17,
        "risparmio": "Risparmi il 55% rispetto agli esami singoli",
        "icona": "🤰"
    },
    {
        "id": "medicina-lavoro",
        "nome": "Medicina del Lavoro (Aziende)",
        "prezzo": 79.00,
        "descrizione": "Servizio completo per aziende. Nomina medico competente, visite e idoneità in un'unica sede.",
        "target": [
            "aziende",
            "dipendenti",
            "b2b"
        ],
        "tags": [
            "medicina del lavoro",
            "visita aziendale",
            "medico competente",
            "idoneità",
            "sicurezza sul lavoro",
            "sorveglianza sanitaria",
            "lavoro",
            "azienda"
        ],
        "esami_chiave": [
            "visita-medica",
            "audiometria",
            "spirometria",
            "visiotest",
            "esami-sangue",
            "ecg",
            "drug-test"
        ],
        "esami_count": 7,
        "risparmio": "Prezzo per dipendente",
        "icona": "🏭",
        "url": "pages/medicina-lavoro.html",
        "bookingType": "direct"
    }
];

  // =============================================
  // 2. LISTINO ESAMI INTELLIGENTE (1136 ESAMI)
  // =============================================
  const listino = [
    {
        "id": "11-desossicorticosterone-doc",
        "nome": "11-DESOSSICORTICOSTERONE (DOC)",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "1-2-cicloesandiolo-urine-f-t",
        "nome": "1-2 CICLOESANDIOLO URINE F.T.",
        "prezzo": 10.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "17-beta-estradiolo-leggere-popup",
        "nome": "17 beta Estradiolo  - LEGGERE POPUP",
        "prezzo": 22.0,
        "cat": "Ormoni",
        "sintomi": [
            "menopausa",
            "infertilita"
        ],
        "referto": "48-72h",
        "upsell": "donna-over40"
    },
    {
        "id": "17-chetosteroidi-urine-24h",
        "nome": "17 CHETOSTEROIDI URINE 24H",
        "prezzo": 10.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "17-oh-progesterone",
        "nome": "17-OH-PROGESTERONE",
        "prezzo": 13.2,
        "cat": "Ormoni",
        "sintomi": [
            "infertilita"
        ],
        "referto": "48-72h"
    },
    {
        "id": "2-5-esandione-urine-f-t",
        "nome": "2-5 ESANDIONE URINE F.T.",
        "prezzo": 15.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "a-a-helicobacter-pylori-iga",
        "nome": "A.A. HELICOBACTER PYLORI IgA",
        "prezzo": 12.7,
        "cat": "Autoimmunità",
        "sintomi": [
            "problemi_digestivi",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "a-a-helicobacter-pylori-igg",
        "nome": "A.A. HELICOBACTER PYLORI IgG",
        "prezzo": 12.7,
        "cat": "Autoimmunità",
        "sintomi": [
            "problemi_digestivi",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ab-anticorpi-sars-cov-2-igg-ii-proteina-spike-quan",
        "nome": "AB ANTICORPI SARS COV-2 IgG II PROTEINA SPIKE (QUANTITATIVA)",
        "prezzo": 70.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "acacia-acacia-longifolia-ige-specifiche",
        "nome": "ACACIA (ACACIA LONGIFOLIA) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "acarus-siro-ige-specifiche",
        "nome": "ACARUS SIRO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "acciuga-ige-specifiche",
        "nome": "ACCIUGA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "acero-acer-negundo-ige-specifiche",
        "nome": "ACERO (ACER NEGUNDO) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "acetonemia-acetone-urine-fine-turno",
        "nome": "ACETONEMIA (ACETONE URINE FINE TURNO)",
        "prezzo": 45.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acidi-biliari",
        "nome": "ACIDI BILIARI",
        "prezzo": 11.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "acidi-grassi-a-catena-lunga-e-rapporto-omega",
        "nome": "ACIDI GRASSI A CATENA LUNGA E RAPPORTO OMEGA",
        "prezzo": 100.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "acidi-organici-urinari",
        "nome": "ACIDI ORGANICI URINARI",
        "prezzo": 415.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "acido-5-oh-indolacetico-urine-24h",
        "nome": "ACIDO 5-OH-INDOLACETICO URINE 24H",
        "prezzo": 22.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "acido-butossiacetico-urine-f-t",
        "nome": "ACIDO BUTOSSIACETICO URINE F.T.",
        "prezzo": 39.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-delta-aminolevulinico-ala",
        "nome": "Acido Delta Aminolevulinico (ALA)",
        "prezzo": 39.8,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "acido-fenilmercapturico",
        "nome": "Acido fenilmercapturico",
        "prezzo": 30.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "acido-folico-folati",
        "nome": "ACIDO FOLICO (FOLATI)",
        "prezzo": 9.9,
        "cat": "Vitamina/Minerali",
        "sintomi": [
            "stanchezza",
            "anemia"
        ],
        "referto": "48-72h",
        "upsell": "donna-under40"
    },
    {
        "id": "acido-formico-formiati-urine-f-t",
        "nome": "ACIDO FORMICO (FORMIATI) URINE F.T.",
        "prezzo": 18.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-ippurico-urine-f-t",
        "nome": "ACIDO IPPURICO URINE F.T.",
        "prezzo": 15.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-ippurico-urine-i-t",
        "nome": "ACIDO IPPURICO URINE I.T",
        "prezzo": 15.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-lattico",
        "nome": "ACIDO LATTICO",
        "prezzo": 9.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "acido-mandelico-acido-fenilgliossilico-urine-f-t",
        "nome": "ACIDO MANDELICO + ACIDO FENILGLIOSSILICO URINE F.T.",
        "prezzo": 28.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-mandelico-acido-fenilgliossilico-urine-i-t",
        "nome": "ACIDO MANDELICO + ACIDO FENILGLIOSSILICO URINE I.T.",
        "prezzo": 28.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-mandelico-urine-f-t",
        "nome": "ACIDO MANDELICO URINE F.T.",
        "prezzo": 14.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-mandelico-urine-i-t",
        "nome": "ACIDO MANDELICO URINE I.T.",
        "prezzo": 14.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-metilippurico-urine-f-t",
        "nome": "ACIDO METILIPPURICO URINE F.T.",
        "prezzo": 14.9,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-metilippurico-urine-i-t",
        "nome": "ACIDO METILIPPURICO URINE I.T.",
        "prezzo": 14.9,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-metilmalonico",
        "nome": "ACIDO METILMALONICO",
        "prezzo": 235.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "acido-micofenolico-micofenolato-mofetile",
        "nome": "ACIDO MICOFENOLICO (MICOFENOLATO MOFETILE)",
        "prezzo": 162.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "acido-ossalico-urine-24h",
        "nome": "ACIDO OSSALICO URINE 24H",
        "prezzo": 27.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "acido-ossalico-urine-f-t",
        "nome": "ACIDO OSSALICO URINE F.T.",
        "prezzo": 32.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-piruvico",
        "nome": "ACIDO PIRUVICO",
        "prezzo": 100.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "acido-s-fenilmercapturico-urine-f-t",
        "nome": "ACIDO S-FENILMERCAPTURICO URINE F.T.",
        "prezzo": 32.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-transmuconico-urine-f-t",
        "nome": "ACIDO TRANSMUCONICO URINE F.T.",
        "prezzo": 36.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-transmuconico-urine-i-t",
        "nome": "ACIDO TRANSMUCONICO URINE I.T.",
        "prezzo": 36.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-tricloroacetico-tca-urine-f-t",
        "nome": "ACIDO TRICLOROACETICO (TCA) URINE F.T.",
        "prezzo": 11.9,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "acido-urico",
        "nome": "ACIDO URICO",
        "prezzo": 3.5,
        "cat": "Renale",
        "sintomi": [
            "dolori_articolari",
            "controllo_reni"
        ],
        "referto": "48-72h"
    },
    {
        "id": "acido-valproico-depakin-dipropilacetico",
        "nome": "ACIDO VALPROICO (DEPAKIN) (DIPROPILACETICO)",
        "prezzo": 12.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "acido-vanilmandelico-urine-24h",
        "nome": "ACIDO VANILMANDELICO URINE 24H",
        "prezzo": 31.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "acr-rapporto-mg-di-microalbuminuria-g-di-creatinin",
        "nome": "ACR: Rapporto mg di Microalbuminuria  / g di creatinina urinaria",
        "prezzo": 15.0,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "renale"
    },
    {
        "id": "acth-ormone-adrenocorticotropo",
        "nome": "ACTH (ORMONE ADRENOCORTICOTROPO)",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "adenovirus-ricerca-antigene-nelle-feci",
        "nome": "ADENOVIRUS RICERCA ANTIGENE NELLE FECI",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "adiponectina",
        "nome": "ADIPONECTINA",
        "prezzo": 85.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "adrenalina-noradrenalina-plasmatica",
        "nome": "ADRENALINA-NORADRENALINA PLASMATICA",
        "prezzo": 34.9,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "adrenalina-noradrenalina-urine-24h",
        "nome": "ADRENALINA-NORADRENALINA URINE 24H",
        "prezzo": 65.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "agglutine-a-freddo",
        "nome": "AGGLUTINE A FREDDO",
        "prezzo": 40.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "aglio-ige-specifiche",
        "nome": "AGLIO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "albicocca-ige-specifiche",
        "nome": "ALBICOCCA (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "albume-ige-specifiche",
        "nome": "ALBUME (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "albumina",
        "nome": "ALBUMINA",
        "prezzo": 3.5,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato"
        ],
        "referto": "48-72h"
    },
    {
        "id": "albuminuria-24h",
        "nome": "ALBUMINURIA 24H",
        "prezzo": 4.0,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato"
        ],
        "referto": "48-72h"
    },
    {
        "id": "alcolemia",
        "nome": "ALCOLEMIA",
        "prezzo": 20.0,
        "cat": "Tossicologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "aldolasi",
        "nome": "ALDOLASI",
        "prezzo": 3.3,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "aldosterone-in-ortostatismo",
        "nome": "ALDOSTERONE IN ORTOSTATISMO",
        "prezzo": 16.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "aldosterone-urine-24h",
        "nome": "ALDOSTERONE URINE 24H",
        "prezzo": 21.9,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "alex-test",
        "nome": "ALEX TEST",
        "prezzo": 310.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "alfa-1-microglobulina",
        "nome": "ALFA 1 MICROGLOBULINA",
        "prezzo": 28.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "alfa-2-macroglobulina",
        "nome": "ALFA 2 MACROGLOBULINA",
        "prezzo": 40.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "alfa-latto-albumina-ige-specifiche",
        "nome": "ALFA LATTO-ALBUMINA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "alfa-1-antitripsina",
        "nome": "ALFA-1-ANTITRIPSINA",
        "prezzo": 12.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "alfa-1-antitripsina-fecale",
        "nome": "ALFA-1-ANTITRIPSINA FECALE",
        "prezzo": 55.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "alfa-1-glicoproteina-mucoproteina",
        "nome": "ALFA-1-GLICOPROTEINA (MUCOPROTEINA)",
        "prezzo": 12.3,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "alfafetoproteina-afp",
        "nome": "ALFAFETOPROTEINA (AFP)",
        "prezzo": 16.9,
        "cat": "Tumore/Markers",
        "sintomi": [
            "dimagrimento"
        ],
        "referto": "48-72h"
    },
    {
        "id": "alluminio-sierico",
        "nome": "ALLUMINIO SIERICO",
        "prezzo": 20.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "alluminio-urine-f-t",
        "nome": "ALLUMINIO URINE F.T.",
        "prezzo": 30.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "alluminio-urine-i-t",
        "nome": "ALLUMINIO URINE I.T.",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "alpha-gal-galactose-alpha-1-3-galactose",
        "nome": "ALPHA-GAL GALACTOSE-ALPHA-1,3-GALACTOSE",
        "prezzo": 78.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "alt-a1-alternaria-alternata",
        "nome": "ALT A1 ALTERNARIA ALTERNATA",
        "prezzo": 82.5,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "alternaria-alternata-ige-specifiche",
        "nome": "ALTERNARIA ALTERNATA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Epatico",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "amaranto-comune-amaranthus-retroflexus-ige-specifi",
        "nome": "AMARANTO COMUNE (AMARANTHUS RETROFLEXUS) (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ambrosia-elatior-ambrosia-artemisifolia-ige-specif",
        "nome": "AMBROSIA ELATIOR (AMBROSIA ARTEMISIFOLIA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ambrosia-gigante-ambrosia-trifida-ige-specifiche",
        "nome": "AMBROSIA GIGANTE (AMBROSIA TRIFIDA) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ambrosia-occidentale-ambrosia-psilostachya-ige-spe",
        "nome": "AMBROSIA OCCIDENTALE (AMBROSIA PSILOSTACHYA) (IgE SPECIFICHE)",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "amilasi",
        "nome": "AMILASI",
        "prezzo": 3.5,
        "cat": "Altro",
        "sintomi": [
            "problemi_digestivi"
        ],
        "referto": "48-72h"
    },
    {
        "id": "amilasi-isoenzimi",
        "nome": "AMILASI ISOENZIMI",
        "prezzo": 65.0,
        "cat": "Altro",
        "sintomi": [
            "problemi_digestivi"
        ],
        "referto": "48-72h"
    },
    {
        "id": "amilasi-pancreatica",
        "nome": "AMILASI PANCREATICA",
        "prezzo": 12.0,
        "cat": "Altro",
        "sintomi": [
            "problemi_digestivi"
        ],
        "referto": "48-72h"
    },
    {
        "id": "amilasuria-urine-spot",
        "nome": "AMILASURIA URINE  spot",
        "prezzo": 2.99,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "aminoacidi-plasmatici",
        "nome": "AMINOACIDI PLASMATICI",
        "prezzo": 350.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "amiodarone-e-metaboliti",
        "nome": "AMIODARONE E METABOLITI",
        "prezzo": 229.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ammonio",
        "nome": "AMMONIO",
        "prezzo": 20.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "amoxicillina-ige-specifiche",
        "nome": "AMOXICILLINA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ampicillina-ige-specifiche",
        "nome": "AMPICILLINA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anacardio-ige-specifiche",
        "nome": "ANACARDIO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "analisi-genetica-di-ii-livello",
        "nome": "ANALISI GENETICA DI II LIVELLO",
        "prezzo": 170.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "7-15gg"
    },
    {
        "id": "ananas-ige-specifiche",
        "nome": "ANANAS (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "androstenediolo-glucuronide",
        "nome": "ANDROSTENEDIOLO GLUCURONIDE",
        "prezzo": 12.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anexina-v-igg",
        "nome": "ANEXINA V IGG",
        "prezzo": 62.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "angiotensina-ii",
        "nome": "ANGIOTENSINA II",
        "prezzo": 124.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anguria-ige-specifiche",
        "nome": "ANGURIA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anisakis-ige-specifiche",
        "nome": "ANISAKIS (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "annexina-v-igg",
        "nome": "Annexina V IgG",
        "prezzo": 65.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "antibiogramma",
        "nome": "ANTIBIOGRAMMA",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "antibiogramma-mic-batteri-gram-negativi",
        "nome": "ANTIBIOGRAMMA (MIC) batteri gram negativi",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "antibiogramma-mic-batteri-gram-positivi",
        "nome": "ANTIBIOGRAMMA (MIC) batteri gram positivi",
        "prezzo": 45.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "antibiogramma-per-micoplasma-ureaplasma",
        "nome": "ANTIBIOGRAMMA PER MICOPLASMA/UREAPLASMA",
        "prezzo": 70.0,
        "cat": "Renale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "antibiogramma-vitek-ast-n379",
        "nome": "ANTIBIOGRAMMA VITEK AST N379",
        "prezzo": 45.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "antibiotici-aminoglicosidi-vancomicina",
        "nome": "ANTIBIOTICI AMINOGLICOSIDI: VANCOMICINA",
        "prezzo": 44.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-core-virus-b-hbcab-totali",
        "nome": "ANTICORPI ANTI - CORE VIRUS B (HBCAB TOTALI)",
        "prezzo": 12.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-bp180",
        "nome": "ANTICORPI ANTI BP180",
        "prezzo": 33.9,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-gangliosidi-profilo-completo-igg",
        "nome": "ANTICORPI ANTI GANGLIOSIDI - Profilo completo IgG",
        "prezzo": 70.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-hdv-virus-epatite-delta",
        "nome": "ANTICORPI ANTI HDV (VIRUS EPATITE DELTA)",
        "prezzo": 63.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-insulina",
        "nome": "ANTICORPI ANTI INSULINA",
        "prezzo": 45.9,
        "cat": "Glicemia/Diabete",
        "sintomi": [
            "aumento_peso"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-mag",
        "nome": "Anticorpi Anti Mag",
        "prezzo": 63.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-musk",
        "nome": "ANTICORPI ANTI MUSK",
        "prezzo": 81.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-pemfigoide-bolloso-bp230",
        "nome": "Anticorpi anti Pemfigoide bolloso BP230",
        "prezzo": 33.9,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-sars-cov-2-igm-igg",
        "nome": "ANTICORPI ANTI SARS-CoV-2 (IgM, IgG)",
        "prezzo": 55.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-sars-cov-2-igg-quantitativo",
        "nome": "ANTICORPI ANTI SARS-COV-2 IGG (QUANTITATIVO)",
        "prezzo": 40.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ssa",
        "nome": "ANTICORPI ANTI SSA",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ssb",
        "nome": "ANTICORPI ANTI SSB",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-21-idrossilasi",
        "nome": "anticorpi anti-21 Idrossilasi",
        "prezzo": 97.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-adenovirus-igg",
        "nome": "ANTICORPI ANTI-ADENOVIRUS IgG",
        "prezzo": 14.2,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-adenovirus-igm",
        "nome": "ANTICORPI ANTI-ADENOVIRUS IgM",
        "prezzo": 14.2,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ameba-entamoeba-histolytica",
        "nome": "ANTICORPI ANTI-AMEBA (ENTAMOEBA HISTOLYTICA)",
        "prezzo": 74.2,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-bartonella-henselae-igg",
        "nome": "ANTICORPI ANTI-BARTONELLA HENSELAE IgG",
        "prezzo": 45.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-bartonella-henselae-igm",
        "nome": "ANTICORPI ANTI-BARTONELLA HENSELAE IgM",
        "prezzo": 68.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-bartonella-quintana-igg",
        "nome": "ANTICORPI ANTI-BARTONELLA QUINTANA IgG",
        "prezzo": 24.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-bartonella-quintana-igm",
        "nome": "ANTICORPI ANTI-BARTONELLA QUINTANA IgM",
        "prezzo": 24.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-beta-2-glicoproteina-igg",
        "nome": "ANTICORPI ANTI-BETA 2 GLICOPROTEINA IgG",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-beta-2-glicoproteina-igm",
        "nome": "ANTICORPI ANTI-BETA 2 GLICOPROTEINA IgM",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-borrelia-burgdorferi-igg",
        "nome": "ANTICORPI ANTI-BORRELIA BURGDORFERI IgG",
        "prezzo": 14.2,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-borrelia-burgdorferi-igm",
        "nome": "ANTICORPI ANTI-BORRELIA BURGDORFERI IgM",
        "prezzo": 14.2,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-candida-albicans-igg",
        "nome": "ANTICORPI ANTI-CANDIDA ALBICANS IgG",
        "prezzo": 24.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-candida-albicans-igm",
        "nome": "ANTICORPI ANTI-CANDIDA ALBICANS IgM",
        "prezzo": 24.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-cardiolipina-iga",
        "nome": "ANTICORPI ANTI-CARDIOLIPINA IgA",
        "prezzo": 35.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-cardiolipina-igg",
        "nome": "ANTICORPI ANTI-CARDIOLIPINA IgG",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-cardiolipina-igm",
        "nome": "ANTICORPI ANTI-CARDIOLIPINA IgM",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-cellule-parietali-apca",
        "nome": "ANTICORPI ANTI-CELLULE PARIETALI (APCA)",
        "prezzo": 14.2,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-centromero-cenp-b",
        "nome": "ANTICORPI ANTI-CENTROMERO (CENP-B)",
        "prezzo": 21.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-chlamydia-pneumoniae-iga",
        "nome": "ANTICORPI ANTI-CHLAMYDIA PNEUMONIAE IgA",
        "prezzo": 50.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "7-15gg"
    },
    {
        "id": "anticorpi-anti-chlamydia-pneumoniae-igg",
        "nome": "ANTICORPI ANTI-CHLAMYDIA PNEUMONIAE IgG",
        "prezzo": 50.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "7-15gg"
    },
    {
        "id": "anticorpi-anti-chlamydia-pneumoniae-igm",
        "nome": "ANTICORPI ANTI-CHLAMYDIA PNEUMONIAE IgM",
        "prezzo": 50.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "7-15gg"
    },
    {
        "id": "anticorpi-anti-chlamydia-trachomatis-iga",
        "nome": "ANTICORPI ANTI-CHLAMYDIA TRACHOMATIS IgA",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "7-15gg"
    },
    {
        "id": "anticorpi-anti-chlamydia-trachomatis-igg",
        "nome": "ANTICORPI ANTI-CHLAMYDIA TRACHOMATIS IgG",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "7-15gg"
    },
    {
        "id": "anticorpi-anti-chlamydia-trachomatis-igm",
        "nome": "ANTICORPI ANTI-CHLAMYDIA TRACHOMATIS IgM",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "7-15gg"
    },
    {
        "id": "anticorpi-anti-citomegalovirus-igg",
        "nome": "ANTICORPI ANTI-CITOMEGALOVIRUS IgG",
        "prezzo": 12.7,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-citomegalovirus-igm",
        "nome": "ANTICORPI ANTI-CITOMEGALOVIRUS IgM",
        "prezzo": 13.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-citoplasma-granulociti-neutrofili-a",
        "nome": "ANTICORPI ANTI-CITOPLASMA GRANULOCITI NEUTROFILI (ANCA)",
        "prezzo": 15.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-citrullina",
        "nome": "ANTICORPI ANTI-CITRULLINA",
        "prezzo": 31.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-cromatina-nucleosoma",
        "nome": "Anticorpi anti-cromatina (nucleosoma)",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-desmogleina-1-dsg1",
        "nome": "ANTICORPI ANTI-DESMOGLEINA 1 (DSG1)",
        "prezzo": 40.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-desmogleina-3-dsg3",
        "nome": "ANTICORPI ANTI-DESMOGLEINA 3 (DSG3)",
        "prezzo": 40.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-difterite",
        "nome": "ANTICORPI ANTI-DIFTERITE",
        "prezzo": 80.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-dna-nativo",
        "nome": "ANTICORPI ANTI-DNA NATIVO",
        "prezzo": 16.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-dnasi-b",
        "nome": "ANTICORPI ANTI-DNASI B",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-echo-virus-neurotropi-ig-totali",
        "nome": "ANTICORPI ANTI-ECHO VIRUS NEUROTROPI Ig TOTALI",
        "prezzo": 38.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-echo-virus-pneumotropi-ig-totali",
        "nome": "ANTICORPI ANTI-ECHO VIRUS PNEUMOTROPI Ig TOTALI",
        "prezzo": 38.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ena-screening",
        "nome": "ANTICORPI ANTI-ENA (SCREENING)",
        "prezzo": 28.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ena-jo-1",
        "nome": "ANTICORPI ANTI-ENA JO-1",
        "prezzo": 11.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ena-rnp",
        "nome": "ANTICORPI ANTI-ENA RNP",
        "prezzo": 11.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ena-scl-70",
        "nome": "ANTICORPI ANTI-ENA SCL-70",
        "prezzo": 11.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ena-sm",
        "nome": "ANTICORPI ANTI-ENA SM",
        "prezzo": 11.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ena-ssa-ro-52kd",
        "nome": "ANTICORPI ANTI-ENA SSA (RO) 52KD",
        "prezzo": 11.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ena-ssa-ro-60kd",
        "nome": "ANTICORPI ANTI-ENA SSA (RO) 60KD",
        "prezzo": 11.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ena-ssa-ro",
        "nome": "ANTICORPI ANTI-ENA SSA/RO",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-ena-ssb-la",
        "nome": "ANTICORPI ANTI-ENA SSB (LA)",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-endomisio-ema-iga",
        "nome": "ANTICORPI ANTI-ENDOMISIO (EMA) IgA",
        "prezzo": 18.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-endomisio-ema-igg",
        "nome": "ANTICORPI ANTI-ENDOMISIO (EMA) IgG",
        "prezzo": 18.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-epstein-barr-virus-ea-igg",
        "nome": "ANTICORPI ANTI-EPSTEIN BARR VIRUS EA IgG",
        "prezzo": 16.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-epstein-barr-virus-ebna-igg",
        "nome": "ANTICORPI ANTI-EPSTEIN BARR VIRUS EBNA IgG",
        "prezzo": 12.4,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-epstein-barr-virus-vca-igg",
        "nome": "ANTICORPI ANTI-EPSTEIN BARR VIRUS VCA IgG",
        "prezzo": 13.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-epstein-barr-virus-vca-igm",
        "nome": "ANTICORPI ANTI-EPSTEIN BARR VIRUS VCA IgM",
        "prezzo": 15.2,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-fattore-intrinseco",
        "nome": "ANTICORPI ANTI-FATTORE INTRINSECO",
        "prezzo": 50.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-fosfolipidi",
        "nome": "ANTICORPI ANTI-FOSFOLIPIDI",
        "prezzo": 20.8,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "A digiuno da 12 ore"
    },
    {
        "id": "anticorpi-anti-gad-65-decarbossilasi-dell-acido-gl",
        "nome": "ANTICORPI ANTI-GAD 65 (DECARBOSSILASI DELL'ACIDO GLUTAMMICO)",
        "prezzo": 65.2,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-gangliosidi-profilo-completo-igm",
        "nome": "ANTICORPI ANTI-GANGLIOSIDI (PROFILO COMPLETO IGM)",
        "prezzo": 70.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-gliadina-deamidata-iga",
        "nome": "ANTICORPI ANTI-GLIADINA DEAMIDATA IgA",
        "prezzo": 13.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-gliadina-deamidata-igg",
        "nome": "ANTICORPI ANTI-GLIADINA DEAMIDATA IgG",
        "prezzo": 13.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-hav-igg",
        "nome": "ANTICORPI ANTI-HAV IgG",
        "prezzo": 13.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-hav-igm",
        "nome": "ANTICORPI ANTI-HAV IgM",
        "prezzo": 13.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-hbc-igg",
        "nome": "ANTICORPI ANTI-HBc IgG",
        "prezzo": 13.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-hbc-igm",
        "nome": "ANTICORPI ANTI-HBc IgM",
        "prezzo": 13.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-hbeag",
        "nome": "ANTICORPI ANTI-HBeAg",
        "prezzo": 18.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-hbs-totali",
        "nome": "ANTICORPI ANTI-HBs TOTALI",
        "prezzo": 12.7,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-hcv",
        "nome": "ANTICORPI ANTI-HCV",
        "prezzo": 10.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "controllo_fegato"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "anticorpi-anti-hdv-epatite-delta",
        "nome": "ANTICORPI ANTI-HDV - EPATITE DELTA",
        "prezzo": 125.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-helicobacter-pylori-igg",
        "nome": "ANTICORPI ANTI-HELICOBACTER PYLORI IgG",
        "prezzo": 13.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "problemi_digestivi",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-herpes-simplex-tipo-1-igg",
        "nome": "ANTICORPI ANTI-HERPES SIMPLEX TIPO 1 IgG",
        "prezzo": 13.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-herpes-simplex-tipo-1-2-igm",
        "nome": "ANTICORPI ANTI-HERPES SIMPLEX TIPO 1-2 IgM",
        "prezzo": 15.2,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-herpes-simplex-tipo-2-igg",
        "nome": "ANTICORPI ANTI-HERPES SIMPLEX TIPO 2 IgG",
        "prezzo": 13.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-hiv-1-2",
        "nome": "ANTICORPI ANTI-HIV 1-2",
        "prezzo": 13.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "anticorpi-anti-htlv-1-2",
        "nome": "ANTICORPI ANTI-HTLV 1/2",
        "prezzo": 48.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-insula-pancreatica-ica",
        "nome": "ANTICORPI ANTI-INSULA PANCREATICA (ICA)",
        "prezzo": 7.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-legionella",
        "nome": "ANTICORPI ANTI-LEGIONELLA",
        "prezzo": 60.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-leptospira-ig-m",
        "nome": "ANTICORPI ANTI-LEPTOSPIRA (Ig M)",
        "prezzo": 75.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-listeria",
        "nome": "ANTICORPI ANTI-LISTERIA",
        "prezzo": 28.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-microsoma-lkm",
        "nome": "ANTICORPI ANTI-MICROSOMA LKM",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-mitocondri-ama",
        "nome": "ANTICORPI ANTI-MITOCONDRI (AMA)",
        "prezzo": 14.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-morbillo-igg",
        "nome": "ANTICORPI ANTI-MORBILLO IgG",
        "prezzo": 12.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-morbillo-igm",
        "nome": "ANTICORPI ANTI-MORBILLO IgM",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-muscolo-liscio-asma",
        "nome": "ANTICORPI ANTI-MUSCOLO LISCIO (ASMA)",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-muscolo-striato",
        "nome": "ANTICORPI ANTI-MUSCOLO STRIATO",
        "prezzo": 44.9,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-mycoplasma-pneumoniae-igg",
        "nome": "ANTICORPI ANTI-MYCOPLASMA PNEUMONIAE IgG",
        "prezzo": 18.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-mycoplasma-pneumoniae-igm",
        "nome": "ANTICORPI ANTI-MYCOPLASMA PNEUMONIAE IgM",
        "prezzo": 18.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-nucleo-ana",
        "nome": "ANTICORPI ANTI-NUCLEO (ANA)",
        "prezzo": 13.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-parotite-igg",
        "nome": "ANTICORPI ANTI-PAROTITE IgG",
        "prezzo": 12.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-parotite-igm",
        "nome": "ANTICORPI ANTI-PAROTITE IgM",
        "prezzo": 12.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-parvovirus-b19-igg",
        "nome": "ANTICORPI ANTI-PARVOVIRUS B19 IgG",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-parvovirus-b19-igm",
        "nome": "ANTICORPI ANTI-PARVOVIRUS B19 IgM",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-pertosse-igg",
        "nome": "ANTICORPI ANTI-PERTOSSE IgG",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-pertosse-igm",
        "nome": "ANTICORPI ANTI-PERTOSSE IgM",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-piastrine",
        "nome": "ANTICORPI ANTI-PIASTRINE",
        "prezzo": 235.5,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-proteinasi-3-pr3",
        "nome": "ANTICORPI ANTI-PROTEINASI 3 (PR3)",
        "prezzo": 10.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-recettore-acetilcolina-achr",
        "nome": "Anticorpi Anti-recettore Acetilcolina (AChR)",
        "prezzo": 62.22,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-recettore-acetilcolina-nicotinico-m",
        "nome": "ANTICORPI ANTI-RECETTORE ACETILCOLINA (NICOTINICO MUSCOLARE)",
        "prezzo": 110.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-recettori-tsh",
        "nome": "ANTICORPI ANTI-RECETTORI TSH",
        "prezzo": 35.0,
        "cat": "Tiroide",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "perdita_capelli",
            "dimagrimento",
            "menopausa",
            "gravidanza",
            "palpitazioni",
            "insonnia",
            "infertilita",
            "ansia_stress"
        ],
        "referto": "48h",
        "upsell": "donna-under40"
    },
    {
        "id": "anticorpi-anti-reticolina",
        "nome": "ANTICORPI ANTI-RETICOLINA",
        "prezzo": 28.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-antiribosoma",
        "nome": "ANTICORPI ANTIRIBOSOMA",
        "prezzo": 28.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-rosolia-igg",
        "nome": "ANTICORPI ANTI-ROSOLIA IgG",
        "prezzo": 11.7,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "infezioni_frequenti"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "anticorpi-anti-rosolia-igm",
        "nome": "ANTICORPI ANTI-ROSOLIA IgM",
        "prezzo": 11.7,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "infezioni_frequenti"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "anticorpi-anti-schistosoma-mansoni",
        "nome": "ANTICORPI ANTI-SCHISTOSOMA MANSONI",
        "prezzo": 28.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-spermatozoi",
        "nome": "ANTICORPI ANTI-SPERMATOZOI",
        "prezzo": 35.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-surrene",
        "nome": "ANTICORPI ANTI-SURRENE",
        "prezzo": 30.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-tetano",
        "nome": "ANTICORPI ANTI-TETANO",
        "prezzo": 28.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-tireoglobulina",
        "nome": "ANTICORPI ANTI-TIREOGLOBULINA",
        "prezzo": 19.9,
        "cat": "Tiroide",
        "sintomi": [],
        "referto": "48-72h",
        "upsell": "tiroide-plus"
    },
    {
        "id": "anticorpi-anti-tireoperossidasi",
        "nome": "ANTICORPI ANTI-TIREOPEROSSIDASI",
        "prezzo": 19.9,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-toxoplasma-igg",
        "nome": "ANTICORPI ANTI-TOXOPLASMA IgG",
        "prezzo": 10.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "infezioni_frequenti"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "anticorpi-anti-toxoplasma-igm",
        "nome": "ANTICORPI ANTI-TOXOPLASMA IgM",
        "prezzo": 10.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "infezioni_frequenti"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "anticorpi-anti-transglutaminasi-iga",
        "nome": "ANTICORPI ANTI-TRANSGLUTAMINASI IgA",
        "prezzo": 20.3,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-transglutaminasi-igg",
        "nome": "ANTICORPI ANTI-TRANSGLUTAMINASI IgG",
        "prezzo": 21.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-treponema-pallidum-igg",
        "nome": "ANTICORPI ANTI-TREPONEMA PALLIDUM IgG",
        "prezzo": 10.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-treponema-pallidum-igm",
        "nome": "ANTICORPI ANTI-TREPONEMA PALLIDUM IgM",
        "prezzo": 10.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-varicella-herpes-zoster-igg",
        "nome": "ANTICORPI ANTI-VARICELLA (HERPES ZOSTER) IgG",
        "prezzo": 13.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "anticorpi-anti-varicella-herpes-zoster-igm",
        "nome": "ANTICORPI ANTI-VARICELLA (HERPES ZOSTER) IgM",
        "prezzo": 13.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "antigene-carboidratico-ca-125",
        "nome": "ANTIGENE CARBOIDRATICO CA 125",
        "prezzo": 13.5,
        "cat": "Tumore/Markers",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "antigene-carboidratico-ca-15-3",
        "nome": "ANTIGENE CARBOIDRATICO CA 15-3",
        "prezzo": 13.5,
        "cat": "Tumore/Markers",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "antigene-carboidratico-ca-19-9",
        "nome": "ANTIGENE CARBOIDRATICO CA 19-9",
        "prezzo": 13.5,
        "cat": "Tumore/Markers",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "antigene-carboidratico-ca-50",
        "nome": "ANTIGENE CARBOIDRATICO CA 50",
        "prezzo": 45.9,
        "cat": "Tumore/Markers",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "antigene-carboidratico-ca-72-4",
        "nome": "ANTIGENE CARBOIDRATICO CA 72-4",
        "prezzo": 22.0,
        "cat": "Tumore/Markers",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "antigene-carcinoembrionale-cea",
        "nome": "ANTIGENE CARCINOEMBRIONALE (CEA)",
        "prezzo": 10.0,
        "cat": "Tumore/Markers",
        "sintomi": [
            "dimagrimento",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "antigene-hbeag",
        "nome": "ANTIGENE HBeAg",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "antigene-polipeptidico-tissutale-tpa",
        "nome": "ANTIGENE POLIPEPTIDICO TISSUTALE (TPA)",
        "prezzo": 21.5,
        "cat": "Coagulazione",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "antigene-prostatico-specifico-psa-totale",
        "nome": "ANTIGENE PROSTATICO SPECIFICO (PSA) TOTALE",
        "prezzo": 10.0,
        "cat": "Tumore/Markers",
        "sintomi": [
            "allergie",
            "controllo_prostata"
        ],
        "referto": "48-72h",
        "upsell": "uomo-under40"
    },
    {
        "id": "antimicogramma",
        "nome": "ANTIMICOGRAMMA",
        "prezzo": 30.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "antimieloperossidasi-mpo",
        "nome": "ANTIMIELOPEROSSIDASI (MPO)",
        "prezzo": 28.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "antimonio-urine-f-t",
        "nome": "ANTIMONIO URINE F.T.",
        "prezzo": 22.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "antiproteinasi-3-pr3",
        "nome": "ANTIPROTEINASI 3 (PR3)",
        "prezzo": 10.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "antitrombina",
        "nome": "ANTITROMBINA",
        "prezzo": 4.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ape-apis-mellifera-ige-specifiche",
        "nome": "APE (APIS MELLIFERA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "apolipoproteina-a1",
        "nome": "APOLIPOPROTEINA A1",
        "prezzo": 13.0,
        "cat": "Lipidico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "apolipoproteina-b",
        "nome": "APOLIPOPROTEINA B",
        "prezzo": 12.0,
        "cat": "Lipidico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "aptoglobina",
        "nome": "APTOGLOBINA",
        "prezzo": 9.5,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "arachide-ige-specifiche",
        "nome": "ARACHIDE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "aragosta-ige-specifiche",
        "nome": "ARAGOSTA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "arancia-ige-specifiche",
        "nome": "ARANCIA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "argento-ematico",
        "nome": "ARGENTO EMATICO",
        "prezzo": 56.2,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "argento-urine-f-t",
        "nome": "ARGENTO URINE F.T.",
        "prezzo": 318.3,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "aringa-ige-specifiche",
        "nome": "ARINGA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "arsenico-urine-f-t",
        "nome": "ARSENICO URINE F.T.",
        "prezzo": 34.2,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "asca-anticorpi-anti-saccharomyces-cerevisiae-iga",
        "nome": "ASCA - ANTICORPI ANTI-SACCHAROMYCES CEREVISIAE IgA",
        "prezzo": 31.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "asca-anticorpi-anti-saccharomyces-cerevisiae-igg",
        "nome": "ASCA - ANTICORPI ANTI-SACCHAROMYCES CEREVISIAE IgG",
        "prezzo": 33.4,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "asparago-ige-specifiche",
        "nome": "ASPARAGO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "aspergillus-fumigatus-ige-specifiche",
        "nome": "ASPERGILLUS FUMIGATUS (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "aspergillus-niger-ige-specifiche",
        "nome": "ASPERGILLUS NIGER (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "assenzio-artemisia-absinthium-ige-specifiche",
        "nome": "ASSENZIO (ARTEMISIA ABSINTHIUM) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "assenzio-selvatico-artemisia-vulgaris-ige-specific",
        "nome": "ASSENZIO SELVATICO (ARTEMISIA VULGARIS) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "atrofia-muscolare-spinale",
        "nome": "ATROFIA MUSCOLARE SPINALE",
        "prezzo": 130.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "avena-avena-sativa-ige-specifiche",
        "nome": "AVENA (AVENA SATIVA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "avena-ige-specifiche",
        "nome": "AVENA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "azotemia",
        "nome": "AZOTEMIA",
        "prezzo": 1.99,
        "cat": "Renale",
        "sintomi": [
            "controllo_reni"
        ],
        "referto": "48-72h",
        "upsell": "renale"
    },
    {
        "id": "azoturia-urine-24h",
        "nome": "AZOTURIA URINE 24H",
        "prezzo": 3.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "bambagiona-holcus-lanatus-ige-specifiche",
        "nome": "BAMBAGIONA (HOLCUS LANATUS) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "banana-ige-specifiche",
        "nome": "BANANA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "barbiturici-sierici",
        "nome": "BARBITURICI SIERICI",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "bario-urine-f-t",
        "nome": "BARIO URINE F.T.",
        "prezzo": 322.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "bartonella-ricerca-anticorpi-igg-e-igm",
        "nome": "BARTONELLA RICERCA ANTICORPI IgG e IgM",
        "prezzo": 33.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "basilico-ige-specifiche",
        "nome": "BASILICO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "benzene-ematico",
        "nome": "BENZENE EMATICO",
        "prezzo": 23.1,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "benzene-urine-f-t",
        "nome": "BENZENE URINE F.T.",
        "prezzo": 23.1,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "benzene-urine-i-t",
        "nome": "BENZENE URINE I.T.",
        "prezzo": 23.1,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "benzodiazepine-sieriche",
        "nome": "BENZODIAZEPINE SIERICHE",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "benzodiazepine-urinarie",
        "nome": "BENZODIAZEPINE URINARIE",
        "prezzo": 20.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "beta-2-microglobulina-sierica",
        "nome": "BETA 2 MICROGLOBULINA SIERICA",
        "prezzo": 12.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "beta-2-microglobulina-urine-24h",
        "nome": "BETA 2 MICROGLOBULINA URINE 24H",
        "prezzo": 13.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "beta-2-microglobulina-urine-f-t",
        "nome": "BETA 2 MICROGLOBULINA URINE F.T.",
        "prezzo": 13.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "beta-hcg-plasmatico",
        "nome": "BETA HCG PLASMATICO",
        "prezzo": 15.5,
        "cat": "Ormoni",
        "sintomi": [
            "gravidanza"
        ],
        "referto": "48-72h",
        "urgente": true
    },
    {
        "id": "beta-lattoglobulina-ige-specifiche",
        "nome": "BETA LATTOGLOBULINA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "betulla-betula-verrucosa-ige-specifiche",
        "nome": "BETULLA (BETULA VERRUCOSA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "bicarbonati",
        "nome": "BICARBONATI",
        "prezzo": 4.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "bilirubina-diretta",
        "nome": "BILIRUBINA DIRETTA",
        "prezzo": 2.5,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato",
            "problemi_digestivi"
        ],
        "referto": "48-72h",
        "upsell": "epatico"
    },
    {
        "id": "bilirubina-totale",
        "nome": "BILIRUBINA TOTALE",
        "prezzo": 3.5,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato",
            "problemi_digestivi"
        ],
        "referto": "48-72h",
        "upsell": "epatico"
    },
    {
        "id": "bnp",
        "nome": "BNP",
        "prezzo": 70.0,
        "cat": "Cardiologico",
        "sintomi": [
            "controllo_cuore",
            "palpitazioni"
        ],
        "referto": "48-72h",
        "upsell": "cardio"
    },
    {
        "id": "botrytis-cinerea-ige-specifiche",
        "nome": "BOTRYTIS CINEREA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "brca-plus",
        "nome": "BRCA PLUS",
        "prezzo": 350.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "breath-test-al-lattosio",
        "nome": "BREATH TEST AL LATTOSIO",
        "prezzo": 59.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "breath-test-glucosio",
        "nome": "BREATH TEST GLUCOSIO",
        "prezzo": 61.0,
        "cat": "Glicemia/Diabete",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "dimagrimento",
            "gravidanza"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "A digiuno da 8-12 ore"
    },
    {
        "id": "breath-test-helicobacter",
        "nome": "Breath Test Helicobacter",
        "prezzo": 65.0,
        "cat": "Infettivologia",
        "sintomi": [
            "problemi_digestivi"
        ],
        "referto": "48-72h"
    },
    {
        "id": "broccoli-ige-specifiche",
        "nome": "BROCCOLI (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "c-peptide",
        "nome": "C PEPTIDE",
        "prezzo": 13.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "c-peptide-profilo",
        "nome": "C PEPTIDE PROFILO",
        "prezzo": 12.5,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "c1-esterasi-inibitore",
        "nome": "C1 ESTERASI INIBITORE",
        "prezzo": 51.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "c1-inattivatore",
        "nome": "C1 INATTIVATORE",
        "prezzo": 22.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cacao-ige-specifiche",
        "nome": "CACAO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cadmio-ematico",
        "nome": "CADMIO EMATICO",
        "prezzo": 25.0,
        "cat": "Tossicologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cadmio-urine-f-t",
        "nome": "CADMIO URINE F.T.",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "caffe-ige-specifiche",
        "nome": "CAFFE' (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "calabrone-bianco-dolichovespula-maculata-ige-speci",
        "nome": "CALABRONE BIANCO (DOLICHOVESPULA MACULATA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Infiammazione",
        "sintomi": [
            "dimagrimento",
            "dolori_articolari",
            "allergie",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "calabrone-europeo-vespa-cabro-ige-specifiche",
        "nome": "CALABRONE EUROPEO (VESPA CABRO) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Infiammazione",
        "sintomi": [
            "dimagrimento",
            "dolori_articolari",
            "allergie",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "calabrone-giallo-dolichovespula-arenaria-ige-speci",
        "nome": "CALABRONE GIALLO (DOLICHOVESPULA ARENARIA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Infiammazione",
        "sintomi": [
            "dimagrimento",
            "dolori_articolari",
            "allergie",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "calamaro-ige-specifiche",
        "nome": "CALAMARO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "calcio",
        "nome": "CALCIO",
        "prezzo": 3.5,
        "cat": "Elettroliti",
        "sintomi": [
            "menopausa",
            "palpitazioni"
        ],
        "referto": "48-72h",
        "upsell": "donna-over40"
    },
    {
        "id": "calcio-ionizzato",
        "nome": "CALCIO IONIZZATO",
        "prezzo": 10.0,
        "cat": "Elettroliti",
        "sintomi": [
            "menopausa",
            "palpitazioni"
        ],
        "referto": "48-72h",
        "upsell": "donna-over40"
    },
    {
        "id": "calcitonina",
        "nome": "CALCITONINA",
        "prezzo": 18.0,
        "cat": "Tiroide",
        "sintomi": [],
        "referto": "48-72h",
        "upsell": "tiroide-plus"
    },
    {
        "id": "calciuria-urine-24h",
        "nome": "CALCIURIA URINE 24H",
        "prezzo": 3.8,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "calciuria-urine-spot",
        "nome": "CALCIURIA URINE SPOT",
        "prezzo": 3.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "calprotectina-fecale-quantitativa",
        "nome": "CALPROTECTINA FECALE QUANTITATIVA",
        "prezzo": 28.0,
        "cat": "Fecale",
        "sintomi": [
            "problemi_digestivi"
        ],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "candida-albicans-ige-specifiche",
        "nome": "CANDIDA ALBICANS (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "canna-di-palude-phragmites-communis-ige-specifiche",
        "nome": "CANNA DI PALUDE (PHRAGMITES COMMUNIS) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cannabinoidi-test-di-conferma",
        "nome": "CANNABINOIDI - TEST DI CONFERMA",
        "prezzo": 168.2,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cannabinoidi-matrice-pilifera-valenza-clinica",
        "nome": "CANNABINOIDI MATRICE PILIFERA (VALENZA CLINICA)",
        "prezzo": 250.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cannarecchia-sorghum-halepense-ige-specifiche",
        "nome": "CANNARECCHIA (SORGHUM HALEPENSE) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "capesanta-ige-specifiche",
        "nome": "CAPESANTA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "carbamazepina",
        "nome": "CARBAMAZEPINA",
        "prezzo": 15.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "carbossiemoglobina",
        "nome": "CARBOSSIEMOGLOBINA",
        "prezzo": 12.0,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "carcinoma-cellule-squamose-scc-ta4",
        "nome": "CARCINOMA CELLULE SQUAMOSE (SCC) (TA4)",
        "prezzo": 85.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cariotipo-metafase-linfocitario",
        "nome": "CARIOTIPO METAFASE LINFOCITARIO",
        "prezzo": 180.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cariotipo-su-sangue-periferico-citogenetica-classi",
        "nome": "Cariotipo su sangue periferico (citogenetica classica)",
        "prezzo": 99.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "cariotipo-su-sangue-periferico-citogenetica-classi",
        "nome": "Cariotipo su sangue periferico (citogenetica classica) – pannello di coppia",
        "prezzo": 190.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "carne-bovina-ige-specifiche",
        "nome": "CARNE BOVINA (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "carne-di-bue-ige-specifiche",
        "nome": "CARNE DI BUE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "carne-di-coniglio-ige-specifiche",
        "nome": "CARNE DI CONIGLIO (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "carne-di-montone-ige-specifiche",
        "nome": "CARNE DI MONTONE (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "carne-di-pollo-ige-specifiche",
        "nome": "CARNE DI POLLO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "carne-di-tacchino-ige-specifiche",
        "nome": "CARNE DI TACCHINO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "carota-ige-specifiche",
        "nome": "CAROTA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "carpino-bianco-carpinus-betulus-ige-specifiche",
        "nome": "CARPINO BIANCO (CARPINUS BETULUS) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "carrieradvance-plus-pannello-di-coppia",
        "nome": "CARRIERADVANCE PLUS (Pannello di coppia)",
        "prezzo": 490.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "caseina-ige-specifiche",
        "nome": "CASEINA (IgE SPECIFICHE)",
        "prezzo": 15.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "castagna-ige-specifiche",
        "nome": "CASTAGNA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Epatico",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "catecolamine-urinarie-24h",
        "nome": "CATECOLAMINE URINARIE 24H",
        "prezzo": 35.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "catene-leggere-kappa-e-lambda-siero",
        "nome": "CATENE LEGGERE KAPPA E LAMBDA SIERO",
        "prezzo": 46.8,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cavolini-di-bruxelles-ige-specifiche",
        "nome": "CAVOLINI DI BRUXELLES (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cavolo-ige-specifiche",
        "nome": "CAVOLO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cdt-transferrina-carboidrato-carente-desialata",
        "nome": "CDT - TRANSFERRINA CARBOIDRATO CARENTE DESIALATA",
        "prezzo": 45.0,
        "cat": "Ematologia",
        "sintomi": [
            "anemia"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ceruloplasmina",
        "nome": "CERULOPLASMINA",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cetriolo-ige-specifiche",
        "nome": "CETRIOLO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "check-uomo-analisi",
        "nome": "CHECK UOMO ANALISI",
        "prezzo": 98.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "48-72h"
    },
    {
        "id": "check-up-bambino",
        "nome": "Check up  BAMBINO",
        "prezzo": 59.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-uomo-under-40",
        "nome": "Check up  uomo under 40",
        "prezzo": 75.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-base",
        "nome": "Check Up base",
        "prezzo": 55.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-donna",
        "nome": "CHECK UP DONNA",
        "prezzo": 113.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-donna-over-40",
        "nome": "Check up donna over 40",
        "prezzo": 125.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-pre-gravidanza",
        "nome": "CHECK UP PRE GRAVIDANZA",
        "prezzo": 185.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-profilo-epatico",
        "nome": "CHECK UP PROFILO EPATICO",
        "prezzo": 75.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-renale",
        "nome": "CHECK UP RENALE",
        "prezzo": 29.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-sport",
        "nome": "CHECK UP SPORT",
        "prezzo": 81.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-tiroide-base",
        "nome": "Check up Tiroide base",
        "prezzo": 37.0,
        "cat": "Tiroide",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-tiroide-plus",
        "nome": "Check up Tiroide Plus",
        "prezzo": 87.0,
        "cat": "Tiroide",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-uomo-dirigenti-bds",
        "nome": "check up uomo dirigenti bds",
        "prezzo": 57.34,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "check-up-uomo-over-40",
        "nome": "Check up uomo over 40",
        "prezzo": 124.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-uomo-platamona",
        "nome": "CHECK UP UOMO PLATAMONA",
        "prezzo": 114.04,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-cardio-pre-visita",
        "nome": "Check-Up Cardio (pre visita)",
        "prezzo": 112.73,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "check-up-donna-under-40",
        "nome": "Check-up donna under 40",
        "prezzo": 97.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "chimotripsina-feci",
        "nome": "CHIMOTRIPSINA (FECI)",
        "prezzo": 29.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "cicloesano-urine-f-t",
        "nome": "CICLOESANO URINE F.T.",
        "prezzo": 28.4,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "cicloesanolo-urine-f-t",
        "nome": "CICLOESANOLO URINE F.T.",
        "prezzo": 28.4,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "ciclosporina",
        "nome": "CICLOSPORINA",
        "prezzo": 30.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ciliegia-ige-specifiche",
        "nome": "CILIEGIA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cioccolato-ige-specifiche",
        "nome": "CIOCCOLATO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cipolla-ige-specifiche",
        "nome": "CIPOLLA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cipresso-cupressus-sempervirens-ige-specifiche",
        "nome": "CIPRESSO (CUPRESSUS SEMPERVIRENS) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cistatina-c",
        "nome": "CISTATINA C",
        "prezzo": 21.0,
        "cat": "Renale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cisticercosi-tenia-solium-anticorpi",
        "nome": "CISTICERCOSI (TENIA SOLIUM) ANTICORPI",
        "prezzo": 148.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cistina-urinaria",
        "nome": "CISTINA URINARIA",
        "prezzo": 121.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "citomegalovirus-avidita-igg",
        "nome": "CITOMEGALOVIRUS AVIDITA' IgG",
        "prezzo": 35.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "citomegalovirus-dna-quantitativo",
        "nome": "CITOMEGALOVIRUS DNA QUANTITATIVO",
        "prezzo": 70.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "citrato-urine-24h",
        "nome": "CITRATO URINE 24H",
        "prezzo": 19.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "ckmb",
        "nome": "ckmb",
        "prezzo": 18.5,
        "cat": "Cardiologico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ck-mb",
        "nome": "CK-MB",
        "prezzo": 18.5,
        "cat": "Cardiologico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ck-mb-massa",
        "nome": "CK-MB MASSA",
        "prezzo": 55.0,
        "cat": "Cardiologico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cladosporium-herbarum-ige-specifiche",
        "nome": "CLADOSPORIUM HERBARUM (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "clearance-della-creatinina",
        "nome": "CLEARANCE DELLA CREATININA",
        "prezzo": 5.0,
        "cat": "Renale",
        "sintomi": [
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "renale"
    },
    {
        "id": "cloro",
        "nome": "CLORO",
        "prezzo": 5.5,
        "cat": "Elettroliti",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cloro-urine-24h",
        "nome": "CLORO URINE 24H",
        "prezzo": 3.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "cloroformio-urine-f-t",
        "nome": "CLOROFORMIO URINE F.T.",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "clostridium-difficile-ricerca-tossina-a-e-b",
        "nome": "CLOSTRIDIUM DIFFICILE RICERCA TOSSINA A e B",
        "prezzo": 43.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "clostridium-difficile-ricerca-tossina-b",
        "nome": "CLOSTRIDIUM DIFFICILE RICERCA TOSSINA B",
        "prezzo": 43.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "clozapina-sierica",
        "nome": "CLOZAPINA SIERICA",
        "prezzo": 79.8,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cobalto-plasmatico",
        "nome": "COBALTO PLASMATICO",
        "prezzo": 20.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cobalto-urine-f-t",
        "nome": "COBALTO URINE F.T.",
        "prezzo": 20.0,
        "cat": "Epatico",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "cobalto-urine-i-t",
        "nome": "COBALTO URINE I.T.",
        "prezzo": 20.0,
        "cat": "Epatico",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "cocaina-test-di-conferma",
        "nome": "COCAINA - TEST DI CONFERMA",
        "prezzo": 168.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cocaina-matrice-pilifera-valenza-clinica",
        "nome": "COCAINA MATRICE PILIFERA (VALENZA CLINICA)",
        "prezzo": 200.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "coda-di-topo-phleum-pratense-ige-specifiche",
        "nome": "CODA DI TOPO (PHLEUM PRATENSE) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "codina-dei-prati-alopecurus-pratensis-ige-specific",
        "nome": "CODINA DEI PRATI (ALOPECURUS PRATENSIS) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "coenzima-q10",
        "nome": "COENZIMA Q10",
        "prezzo": 123.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "colesterolo-hdl",
        "nome": "COLESTEROLO HDL",
        "prezzo": 2.4,
        "cat": "Lipidico",
        "sintomi": [
            "aumento_peso",
            "controllo_cuore",
            "menopausa"
        ],
        "referto": "48h",
        "upsell": "base",
        "prep": "A digiuno da 12 ore"
    },
    {
        "id": "colesterolo-ldl",
        "nome": "COLESTEROLO LDL",
        "prezzo": 2.0,
        "cat": "Lipidico",
        "sintomi": [
            "aumento_peso",
            "controllo_cuore",
            "menopausa"
        ],
        "referto": "48h",
        "upsell": "base",
        "prep": "A digiuno da 12 ore"
    },
    {
        "id": "colesterolo-non-hdl",
        "nome": "COLESTEROLO NON HDL",
        "prezzo": 1.85,
        "cat": "Lipidico",
        "sintomi": [
            "aumento_peso",
            "controllo_cuore",
            "menopausa"
        ],
        "referto": "48h",
        "upsell": "base",
        "prep": "A digiuno da 12 ore"
    },
    {
        "id": "colesterolo-totale",
        "nome": "COLESTEROLO TOTALE",
        "prezzo": 2.5,
        "cat": "Lipidico",
        "sintomi": [
            "aumento_peso",
            "controllo_cuore",
            "menopausa"
        ],
        "referto": "48h",
        "upsell": "base",
        "prep": "A digiuno da 12 ore"
    },
    {
        "id": "colesterolo-vldl",
        "nome": "COLESTEROLO VLDL",
        "prezzo": 40.0,
        "cat": "Lipidico",
        "sintomi": [
            "aumento_peso",
            "controllo_cuore",
            "menopausa"
        ],
        "referto": "48h",
        "upsell": "base",
        "prep": "A digiuno da 12 ore"
    },
    {
        "id": "colinesterasi-che",
        "nome": "COLINESTERASI (CHE)",
        "prezzo": 3.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "colinesterasi-pseudocolinesterasi",
        "nome": "COLINESTERASI (PSEUDOCOLINESTERASI)",
        "prezzo": 3.8,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "colinesterasi-eritrocitaria",
        "nome": "COLINESTERASI ERITROCITARIA",
        "prezzo": 23.9,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "complemento-c1q",
        "nome": "COMPLEMENTO C1q",
        "prezzo": 31.0,
        "cat": "Infiammazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "complemento-c3",
        "nome": "COMPLEMENTO C3",
        "prezzo": 8.3,
        "cat": "Infiammazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "complemento-c3-proattivatore",
        "nome": "COMPLEMENTO C3 PROATTIVATORE",
        "prezzo": 10.9,
        "cat": "Infiammazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "complemento-c4",
        "nome": "COMPLEMENTO C4",
        "prezzo": 8.3,
        "cat": "Infiammazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "conta-eosinofili",
        "nome": "CONTA EOSINOFILI",
        "prezzo": 4.5,
        "cat": "Altro",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "copeptina-pro-avp",
        "nome": "COPEPTINA PRO AVP",
        "prezzo": 84.2,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cortisolo-plasmatico",
        "nome": "CORTISOLO PLASMATICO",
        "prezzo": 16.0,
        "cat": "Ormoni",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "perdita_capelli",
            "insonnia",
            "ansia_stress"
        ],
        "referto": "48-72h",
        "prep": "Prelievo mattutino ore 8-9"
    },
    {
        "id": "cortisolo-salivare",
        "nome": "Cortisolo Salivare",
        "prezzo": 36.0,
        "cat": "Ormoni",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "perdita_capelli",
            "insonnia",
            "ansia_stress"
        ],
        "referto": "48-72h",
        "prep": "Prelievo mattutino ore 8-9"
    },
    {
        "id": "cortisolo-urine-24h",
        "nome": "CORTISOLO URINE 24H",
        "prezzo": 12.0,
        "cat": "Renale",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "perdita_capelli",
            "gravidanza",
            "insonnia",
            "controllo_reni",
            "ansia_stress"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "coxackie-virus-b1-b2-b3-b4-b5-b6-anticorpi-igg",
        "nome": "COXACKIE VIRUS (B1 B2 B3 B4 B5 B6) ANTICORPI IgG",
        "prezzo": 130.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "coxackie-virus-b1-b2-b3-b4-b5-b6-anticorpi-igm",
        "nome": "COXACKIE VIRUS (B1 B2 B3 B4 B5 B6) ANTICORPI IgM",
        "prezzo": 120.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "creatinchinasi-ck",
        "nome": "CREATINCHINASI (CK)",
        "prezzo": 2.5,
        "cat": "Renale",
        "sintomi": [
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "renale"
    },
    {
        "id": "creatinina",
        "nome": "CREATININA",
        "prezzo": 2.0,
        "cat": "Renale",
        "sintomi": [
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "renale"
    },
    {
        "id": "creatinina-urinaria",
        "nome": "CREATININA URINARIA",
        "prezzo": 2.8,
        "cat": "Renale",
        "sintomi": [
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "renale"
    },
    {
        "id": "creatinuria-urine-24h",
        "nome": "CREATINURIA URINE 24H",
        "prezzo": 3.2,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "crioglobuline",
        "nome": "CRIOGLOBULINE",
        "prezzo": 8.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "criptomeria-cryptomeria-japonica-ige-specifiche",
        "nome": "CRIPTOMERIA (CRYPTOMERIA JAPONICA) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Coagulazione",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cromo-ematico",
        "nome": "CROMO EMATICO",
        "prezzo": 15.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cromo-urine-f-t",
        "nome": "CROMO URINE F.T.",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "cromo-urine-i-t",
        "nome": "CROMO URINE I.T.",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "cromogranina-a",
        "nome": "CROMOGRANINA A",
        "prezzo": 79.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "crostacei-ige",
        "nome": "CROSTACEI (IGE)",
        "prezzo": 18.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cumino-ige-specifiche",
        "nome": "CUMINO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cupremia-rame",
        "nome": "CUPREMIA (RAME)",
        "prezzo": 9.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "cupruria-urine-24h",
        "nome": "CUPRURIA (URINE 24H)",
        "prezzo": 10.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "curry-ige-specifiche",
        "nome": "CURRY (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "curva-da-carico-di-glucosio",
        "nome": "Curva da carico di GLUCOSIO",
        "prezzo": 50.0,
        "cat": "Glicemia/Diabete",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "dimagrimento",
            "gravidanza"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "A digiuno da 8-12 ore"
    },
    {
        "id": "curva-da-carico-di-glucosio-arancia",
        "nome": "Curva da carico di GLUCOSIO (ARANCIA)",
        "prezzo": 75.0,
        "cat": "Glicemia/Diabete",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "dimagrimento",
            "gravidanza"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "A digiuno da 8-12 ore"
    },
    {
        "id": "curva-insulinemica",
        "nome": "CURVA INSULINEMICA",
        "prezzo": 45.0,
        "cat": "Glicemia/Diabete",
        "sintomi": [
            "aumento_peso"
        ],
        "referto": "48-72h"
    },
    {
        "id": "curva-insulinemica-6-determinazioni",
        "nome": "Curva insulinemica 6 determinazioni",
        "prezzo": 60.0,
        "cat": "Glicemia/Diabete",
        "sintomi": [
            "aumento_peso"
        ],
        "referto": "48-72h"
    },
    {
        "id": "cyfra-21-1",
        "nome": "CYFRA 21-1",
        "prezzo": 27.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "dao-test",
        "nome": "DAO TEST",
        "prezzo": 112.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "d-dimero",
        "nome": "D-DIMERO",
        "prezzo": 13.5,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "urgente",
        "urgente": true
    },
    {
        "id": "delta-4-androstenedione",
        "nome": "DELTA-4-ANDROSTENEDIONE",
        "prezzo": 12.0,
        "cat": "Ormoni",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "dengue-igg",
        "nome": "DENGUE IgG",
        "prezzo": 41.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "dengue-igm",
        "nome": "DENGUE IgM",
        "prezzo": 41.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "dente-di-leone-taraxacum-vulgare-ige-specifiche",
        "nome": "DENTE DI LEONE (TARAXACUM VULGARE) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "dermatofiti-cute-tampone",
        "nome": "DERMATOFITI CUTE TAMPONE",
        "prezzo": 55.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "dermatophagoides-farinae-ige-specifiche",
        "nome": "DERMATOPHAGOIDES FARINAE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "dermatophagoides-microceras-ige-specifiche",
        "nome": "DERMATOPHAGOIDES MICROCERAS (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "dermatophagoides-pteronyssinus-ige-specifiche",
        "nome": "DERMATOPHAGOIDES PTERONYSSINUS (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Coagulazione",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "desossipiridinolina-urine-24h",
        "nome": "DESOSSIPIRIDINOLINA URINE 24H",
        "prezzo": 45.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "dhea-deidroepiandrosterone",
        "nome": "DHEA (DEIDROEPIANDROSTERONE)",
        "prezzo": 12.5,
        "cat": "Ormoni",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "dhea-s-deidroepiandrosterone-solfato",
        "nome": "DHEA-S (DEIDROEPIANDROSTERONE SOLFATO)",
        "prezzo": 17.5,
        "cat": "Ormoni",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "diagnosi-molecolare-di-emocromatosi-varianti-c282y",
        "nome": "DIAGNOSI MOLECOLARE DI EMOCROMATOSI (VARIANTI C282Y E H63D NEL GENE HFE)",
        "prezzo": 235.0,
        "cat": "Ematologia",
        "sintomi": [
            "stanchezza",
            "dimagrimento",
            "gravidanza",
            "anemia",
            "palpitazioni",
            "infezioni_frequenti"
        ],
        "referto": "24h",
        "upsell": "base"
    },
    {
        "id": "digossina",
        "nome": "DIGOSSINA",
        "prezzo": 16.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "diidrotestosterone-dht",
        "nome": "DIIDROTESTOSTERONE (DHT)",
        "prezzo": 30.0,
        "cat": "Ormoni",
        "sintomi": [
            "perdita_capelli",
            "infertilita",
            "controllo_prostata"
        ],
        "referto": "48-72h",
        "upsell": "uomo-under40"
    },
    {
        "id": "disbiosi-test",
        "nome": "DISBIOSI TEST",
        "prezzo": 90.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "disomia-uniparentale-upd-family-test",
        "nome": "DISOMIA UNIPARENTALE (UPD)- FAMILY TEST",
        "prezzo": 320.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "distrofia-miotonica-dmpk",
        "nome": "DISTROFIA MIOTONICA- DMPK",
        "prezzo": 130.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "distrofia-muscolare-dmd-dmb-mpla-test",
        "nome": "DISTROFIA MUSCOLARE DMD/DMB - MPLA TEST",
        "prezzo": 200.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "dopamina",
        "nome": "DOPAMINA",
        "prezzo": 39.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "dopamina-urine-24h",
        "nome": "DOPAMINA URINE 24H",
        "prezzo": 31.9,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "dosaggio-prolattina",
        "nome": "DOSAGGIO PROLATTINA",
        "prezzo": 15.0,
        "cat": "Ormoni",
        "sintomi": [
            "infertilita"
        ],
        "referto": "48-72h",
        "prep": "A riposo, evitare stress"
    },
    {
        "id": "drom-test",
        "nome": "DROM TEST",
        "prezzo": 37.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "drug-test-2-livello",
        "nome": "DRUG TEST 2 LIVELLO",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "drug-test",
        "nome": "DRUG-TEST",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "e-coli-o-157-nelle-feci",
        "nome": "E. COLI O:157 NELLE FECI",
        "prezzo": 35.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "ebna",
        "nome": "EBNA",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "echiniococco-igg",
        "nome": "ECHINIOCOCCO IGG",
        "prezzo": 26.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "echinococco-abs-screening",
        "nome": "ECHINOCOCCO ABS SCREENING",
        "prezzo": 16.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ecp-proteina-cationica-eosinofila-ecp",
        "nome": "ECP Proteina Cationica Eosinofila (ECP)",
        "prezzo": 79.0,
        "cat": "Altro",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "egfr-velocit-di-filtrazione-glomerulare",
        "nome": "eGFR - Velocità di Filtrazione Glomerulare",
        "prezzo": 5.5,
        "cat": "Renale",
        "sintomi": [
            "controllo_reni"
        ],
        "referto": "48-72h"
    },
    {
        "id": "elastasi-1-pancreatica-fecale",
        "nome": "ELASTASI 1 PANCREATICA FECALE",
        "prezzo": 50.0,
        "cat": "Epatico",
        "sintomi": [
            "problemi_digestivi"
        ],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "elettroforesi-emoglobina-hb",
        "nome": "ELETTROFORESI EMOGLOBINA (Hb)",
        "prezzo": 13.0,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "elettroforesi-proteica",
        "nome": "ELETTROFORESI PROTEICA",
        "prezzo": 10.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "elettroforesi-proteine-urinarie",
        "nome": "ELETTROFORESI PROTEINE URINARIE",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "emocromatosi",
        "nome": "EMOCROMATOSI",
        "prezzo": 130.0,
        "cat": "Ematologia",
        "sintomi": [
            "stanchezza",
            "dimagrimento",
            "gravidanza",
            "anemia",
            "palpitazioni",
            "infezioni_frequenti"
        ],
        "referto": "24h",
        "upsell": "base"
    },
    {
        "id": "emocromo",
        "nome": "Emocromo",
        "prezzo": 6.5,
        "cat": "Ematologia",
        "sintomi": [
            "stanchezza",
            "dimagrimento",
            "gravidanza",
            "anemia",
            "palpitazioni",
            "infezioni_frequenti"
        ],
        "referto": "24h",
        "upsell": "base"
    },
    {
        "id": "emocromo",
        "nome": "EMOCROMO",
        "prezzo": 6.5,
        "cat": "Ematologia",
        "sintomi": [
            "stanchezza",
            "dimagrimento",
            "gravidanza",
            "anemia",
            "palpitazioni",
            "infezioni_frequenti"
        ],
        "referto": "24h",
        "upsell": "base"
    },
    {
        "id": "emocromo-in-citrato",
        "nome": "EMOCROMO IN CITRATO",
        "prezzo": 8.0,
        "cat": "Ematologia",
        "sintomi": [
            "stanchezza",
            "dimagrimento",
            "gravidanza",
            "anemia",
            "palpitazioni",
            "infezioni_frequenti"
        ],
        "referto": "24h",
        "upsell": "base"
    },
    {
        "id": "emoglobina-glicata-hba1c",
        "nome": "EMOGLOBINA GLICATA (HbA1c)",
        "prezzo": 12.0,
        "cat": "Ematologia",
        "sintomi": [
            "aumento_peso"
        ],
        "referto": "48-72h"
    },
    {
        "id": "emopessina",
        "nome": "EMOPESSINA",
        "prezzo": 30.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ena-antigene-ssb-la-abs",
        "nome": "ENA ANTIGENE SSB (LA) ABS",
        "prezzo": 21.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ena-profile",
        "nome": "ENA PROFILE",
        "prezzo": 150.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "endobiome-endometrial-microbiome-analysis",
        "nome": "ENDOBIOME Endometrial microbiome analysis",
        "prezzo": 280.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "48-72h"
    },
    {
        "id": "endorecept-endobiome",
        "nome": "Endorecept + Endobiome",
        "prezzo": 880.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "endorecept-endometrial-receptivity-test",
        "nome": "Endorecept Endometrial receptivity test",
        "prezzo": 600.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "enolasi-neuronale-specifica-nse",
        "nome": "ENOLASI NEURONALE SPECIFICA (NSE)",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "enterovirus-poliovirus-anticorpi",
        "nome": "ENTEROVIRUS (POLIOVIRUS) ANTICORPI",
        "prezzo": 123.9,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "epatite-e-igg",
        "nome": "EPATITE E IgG",
        "prezzo": 58.0,
        "cat": "Epatico",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-cane-ige-specifiche",
        "nome": "EPITELIO CANE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-coniglio-ige-specifiche",
        "nome": "EPITELIO CONIGLIO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-di-capra-ige-specifiche",
        "nome": "EPITELIO DI CAPRA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-di-cavia-ige-specifiche",
        "nome": "EPITELIO DI CAVIA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-di-criceto-ige-specifiche",
        "nome": "EPITELIO DI CRICETO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-di-maiale-ige-specifiche",
        "nome": "EPITELIO DI MAIALE (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-di-pecora",
        "nome": "EPITELIO DI PECORA",
        "prezzo": 18.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-di-ratto-ige-specifiche",
        "nome": "EPITELIO DI RATTO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-di-topo-ige-specifiche",
        "nome": "EPITELIO DI TOPO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-gatto-ige-specifiche",
        "nome": "EPITELIO GATTO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epitelio-lana-di-pecora-ige-specifiche",
        "nome": "EPITELIO/LANA DI PECORA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "epstein-barr-virus-dna",
        "nome": "EPSTEIN BARR VIRUS DNA",
        "prezzo": 108.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "erba-canina-cynodon-dactylon-ige-specifiche",
        "nome": "ERBA CANINA (CYNODON DACTYLON) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "erba-cannuccia-agrostis-alba-ige-specifiche",
        "nome": "ERBA CANNUCCIA (AGROSTIS ALBA) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "erba-mazzolina-dactylis-glomerata-ige-specifiche",
        "nome": "ERBA MAZZOLINA (DACTYLIS GLOMERATA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "erba-parietaria-ige-specifiche",
        "nome": "ERBA PARIETARIA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "erba-vetriola-parietaria-officinalis-ige-specifich",
        "nome": "ERBA VETRIOLA (PARIETARIA OFFICINALIS) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "eritropoietina",
        "nome": "ERITROPOIETINA",
        "prezzo": 22.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame",
        "nome": "ESAME",
        "prezzo": 9.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-chimico-del-calcolo-renale",
        "nome": "ESAME CHIMICO DEL CALCOLO RENALE",
        "prezzo": 35.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-chimico-fisico-delle-urine",
        "nome": "ESAME CHIMICO FISICO DELLE URINE",
        "prezzo": 5.95,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "esame-citologico-urine",
        "nome": "ESAME CITOLOGICO URINE",
        "prezzo": 60.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "esame-citologico-urine-campione-1",
        "nome": "ESAME CITOLOGICO URINE CAMPIONE 1",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "esame-citologico-urine-campione-2",
        "nome": "ESAME CITOLOGICO URINE CAMPIONE 2",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "esame-citologico-urine-campione-3",
        "nome": "ESAME CITOLOGICO URINE CAMPIONE 3",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "esame-colturale-ricerca-clamydia-su-tampone-vagina",
        "nome": "ESAME COLTURALE  RICERCA CLAMYDIA su TAMPONE VAGINALE",
        "prezzo": 9.5,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-clostridium-difficile",
        "nome": "ESAME COLTURALE CLOSTRIDIUM DIFFICILE",
        "prezzo": 35.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-del-liquido-articolare",
        "nome": "ESAME COLTURALE DEL LIQUIDO ARTICOLARE",
        "prezzo": 70.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-delle-feci-coprocoltura-completo",
        "nome": "ESAME COLTURALE DELLE FECI (COPROCOLTURA) COMPLETO",
        "prezzo": 22.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "esame-colturale-dell-urina-urinocoltura",
        "nome": "ESAME COLTURALE DELL'URINA (URINOCOLTURA)",
        "prezzo": 12.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-materiale-liquido",
        "nome": "ESAME COLTURALE MATERIALE LIQUIDO",
        "prezzo": 50.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-pus",
        "nome": "ESAME COLTURALE PUS",
        "prezzo": 70.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-squame-cutanee",
        "nome": "ESAME COLTURALE SQUAME CUTANEE",
        "prezzo": 9.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-anale",
        "nome": "ESAME COLTURALE TAMPONE ANALE",
        "prezzo": 40.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-auricolare-destro",
        "nome": "ESAME COLTURALE TAMPONE AURICOLARE DESTRO",
        "prezzo": 18.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-auricolare-sinistro",
        "nome": "ESAME COLTURALE TAMPONE AURICOLARE SINISTRO",
        "prezzo": 18.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-balano-prepuziale-completo",
        "nome": "ESAME COLTURALE TAMPONE BALANO PREPUZIALE COMPLETO",
        "prezzo": 55.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-cervicale",
        "nome": "ESAME COLTURALE TAMPONE CERVICALE",
        "prezzo": 8.5,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-congiuntivale-destro",
        "nome": "ESAME COLTURALE TAMPONE CONGIUNTIVALE DESTRO",
        "prezzo": 35.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-congiuntivale-sinistro",
        "nome": "ESAME COLTURALE TAMPONE CONGIUNTIVALE SINISTRO",
        "prezzo": 35.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-cutaneo",
        "nome": "ESAME COLTURALE TAMPONE CUTANEO",
        "prezzo": 28.5,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-faringeo",
        "nome": "ESAME COLTURALE TAMPONE FARINGEO",
        "prezzo": 12.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-faringeo-completo",
        "nome": "ESAME COLTURALE TAMPONE FARINGEO COMPLETO",
        "prezzo": 25.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-faringeo-per-ricerca-micet",
        "nome": "ESAME COLTURALE TAMPONE FARINGEO per RICERCA MICETI",
        "prezzo": 18.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-faringeo-per-ricerca-stafi",
        "nome": "ESAME COLTURALE TAMPONE FARINGEO PER RICERCA STAFILOCOCCO",
        "prezzo": 12.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-faringeo-per-ricerca-strep",
        "nome": "ESAME COLTURALE TAMPONE FARINGEO PER RICERCA STREPTOCOCCO",
        "prezzo": 12.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-gengivale",
        "nome": "ESAME COLTURALE TAMPONE GENGIVALE",
        "prezzo": 40.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-linguale",
        "nome": "ESAME COLTURALE TAMPONE LINGUALE",
        "prezzo": 35.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-narice-destra",
        "nome": "ESAME COLTURALE TAMPONE NARICE DESTRA",
        "prezzo": 30.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-narice-sinistra",
        "nome": "ESAME COLTURALE TAMPONE NARICE SINISTRA",
        "prezzo": 30.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-orale",
        "nome": "ESAME COLTURALE TAMPONE ORALE",
        "prezzo": 40.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-rinofaringeo",
        "nome": "ESAME COLTURALE TAMPONE RINOFARINGEO",
        "prezzo": 12.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-uretrale",
        "nome": "ESAME COLTURALE TAMPONE URETRALE",
        "prezzo": 12.5,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-uretrale-per-ricerca-mycop",
        "nome": "ESAME COLTURALE TAMPONE URETRALE  PER RICERCA MYCOPLASMA E UREAPLASMA",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-vaginale",
        "nome": "ESAME COLTURALE TAMPONE VAGINALE",
        "prezzo": 9.8,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-colturale-tampone-vulvare",
        "nome": "ESAME COLTURALE TAMPONE VULVARE",
        "prezzo": 10.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-del-liquido-articolare",
        "nome": "ESAME DEL LIQUIDO ARTICOLARE",
        "prezzo": 55.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-delle-urine",
        "nome": "ESAME DELLE URINE",
        "prezzo": 5.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "esame-micologico",
        "nome": "ESAME MICOLOGICO",
        "prezzo": 9.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-micologico-unghie",
        "nome": "ESAME MICOLOGICO UNGHIE",
        "prezzo": 9.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-microbiologico-prp-plasma-ricco-di-piastrine",
        "nome": "ESAME MICROBIOLOGICO PRP (Plasma Ricco di Piastrine)",
        "prezzo": 40.0,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esame-microscopico-tampone-vaginale",
        "nome": "ESAME MICROSCOPICO TAMPONE VAGINALE",
        "prezzo": 12.5,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esami-check-up-banco-di-sardegna-donna-dirigenti",
        "nome": "Esami check up banco di Sardegna Donna dirigenti",
        "prezzo": 56.29,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "esami-laboratorio-terna",
        "nome": "Esami Laboratorio Terna",
        "prezzo": 93.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esami-laboratorio-terna-metalli",
        "nome": "Esami Laboratorio Terna Metalli",
        "prezzo": 163.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esami-medicina-del-lavoro-base",
        "nome": "Esami medicina del lavoro base",
        "prezzo": 25.48,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esami-prima-visita-torres-professionisti",
        "nome": "Esami prima visita Torres professionisti",
        "prezzo": 140.73,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esano-urine-f-t",
        "nome": "ESANO URINE F.T.",
        "prezzo": 6.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "escrementi-di-piccione-ige-specifiche",
        "nome": "ESCREMENTI DI PICCIONE (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "esecuzione-tampone-rinofaringeo",
        "nome": "ESECUZIONE TAMPONE RINOFARINGEO",
        "prezzo": 20.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "esecuzione-tampone-uretrale",
        "nome": "ESECUZIONE TAMPONE URETRALE",
        "prezzo": 20.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "espettorato-esame-colturale",
        "nome": "ESPETTORATO ESAME COLTURALE",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "estradiolo",
        "nome": "ESTRADIOLO",
        "prezzo": 8.5,
        "cat": "Ormoni",
        "sintomi": [
            "menopausa",
            "infertilita"
        ],
        "referto": "48-72h",
        "upsell": "donna-over40"
    },
    {
        "id": "estriolo",
        "nome": "ESTRIOLO",
        "prezzo": 24.5,
        "cat": "Ormoni",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "estriolo-non-coniugato",
        "nome": "ESTRIOLO NON CONIUGATO",
        "prezzo": 14.0,
        "cat": "Ormoni",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "estrone-e1",
        "nome": "ESTRONE (E1)",
        "prezzo": 39.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "etanolo-urinario",
        "nome": "ETANOLO URINARIO",
        "prezzo": 19.3,
        "cat": "Urinario",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "etanolo-urine-f-t",
        "nome": "ETANOLO URINE F.T.",
        "prezzo": 19.3,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "etg-matrice-pilifera",
        "nome": "ETG MATRICE PILIFERA",
        "prezzo": 200.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "etilglucuronide-matrice-pilifera-etg",
        "nome": "Etilglucuronide matrice pilifera (ETG)",
        "prezzo": 180.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "etosuccimide",
        "nome": "ETOSUCCIMIDE",
        "prezzo": 45.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "euroglyphus-mayne-acari-minori-ige-specifiche",
        "nome": "EUROGLYPHUS MAYNE (Acari minori) (IGE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "faggio-fagus-species-ige-specifiche",
        "nome": "FAGGIO (FAGUS SPECIES) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "fagiolini-ige-specifiche",
        "nome": "FAGIOLINI (IgE SPECIFICHE)",
        "prezzo": 20.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "fagiolo-ige-specifiche",
        "nome": "FAGIOLO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "fagiolo-rosso-ige-specifiche",
        "nome": "FAGIOLO ROSSO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "falsa-ambrosia-ambrosia-acanthicarpa-ige-specifich",
        "nome": "FALSA AMBROSIA (AMBROSIA ACANTHICARPA) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "farina-ige-specifiche",
        "nome": "FARINA (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "farinaccio-chenopodium-album-ige-specifiche",
        "nome": "FARINACCIO (CHENOPODIUM ALBUM) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "fattore-ii-della-coagulazione",
        "nome": "Fattore II della Coagulazione",
        "prezzo": 28.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fattore-v-di-leiden-mutazione-g1691a",
        "nome": "Fattore V di Leiden (mutazione G1691A)",
        "prezzo": 50.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fattore-v-di-leiden-fattore-ii-mthfr-c677",
        "nome": "Fattore V di Leiden + Fattore II + MTHFR C677",
        "prezzo": 196.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fattore-viii",
        "nome": "FATTORE VIII",
        "prezzo": 27.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fattore-x",
        "nome": "FATTORE X",
        "prezzo": 51.3,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fattore-xiii",
        "nome": "FATTORE XIII",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "feci-esame-chimico-fisico-parassitologico",
        "nome": "FECI ESAME CHIMICO-FISICO-PARASSITOLOGICO",
        "prezzo": 11.5,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "fenciclidina-matrice-urinaria",
        "nome": "FENCICLIDINA MATRICE URINARIA",
        "prezzo": 30.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fenilalanina-plasmatica",
        "nome": "FENILALANINA Plasmatica",
        "prezzo": 121.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fenitoina-dintoina-difenilidantoina",
        "nome": "FENITOINA (DINTOINA) (DIFENILIDANTOINA)",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fenolo-urine-f-t",
        "nome": "FENOLO URINE F.T.",
        "prezzo": 22.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "ferritina",
        "nome": "FERRITINA",
        "prezzo": 13.9,
        "cat": "Ematologia",
        "sintomi": [
            "stanchezza",
            "perdita_capelli",
            "anemia",
            "insonnia"
        ],
        "referto": "48h",
        "upsell": "donna-under40"
    },
    {
        "id": "ferro-urinario",
        "nome": "FERRO URINARIO",
        "prezzo": 20.0,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ferro-urine-24h",
        "nome": "FERRO URINE 24H",
        "prezzo": 15.9,
        "cat": "Ematologia",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "ferro-urine-f-t",
        "nome": "FERRO URINE F.T.",
        "prezzo": 20.0,
        "cat": "Ematologia",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "fibrinogeno",
        "nome": "FIBRINOGENO",
        "prezzo": 4.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fibrosi-cistica-139-mutazioni-europe",
        "nome": "FIBROSI CISTICA (139 mutazioni Europe)",
        "prezzo": 145.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fibrosi-cistica-152-mutazioni-europe-di-cui-25-ita",
        "nome": "Fibrosi Cistica (152 mutazioni Europe di cui 25 Italiane) - NGS CE-IVD",
        "prezzo": 165.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fibrosi-cistica-sequenziamento-completo",
        "nome": "Fibrosi Cistica- sequenziamento completo",
        "prezzo": 315.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fish-advance-sper-aneuploidy-test",
        "nome": "Fish Advance Sper Aneuploidy Test",
        "prezzo": 240.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fk506-tacrolimus",
        "nome": "FK506 (TACROLIMUS)",
        "prezzo": 110.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "forfora-cane-ige-specifiche",
        "nome": "FORFORA CANE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "forfora-cavallo-ige-specifiche",
        "nome": "FORFORA CAVALLO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "forfora-mucca-ige-specifiche",
        "nome": "FORFORA MUCCA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "formaggio-fermentato-ige-specifiche",
        "nome": "FORMAGGIO FERMENTATO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "formaggio-molle-ige-specifiche",
        "nome": "FORMAGGIO MOLLE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "formica-solenopsis-invicta-ige-specifiche",
        "nome": "FORMICA (SOLENOPSIS INVICTA) (IgE SPECIFICHE)",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "fosfatasi-acida-totale",
        "nome": "FOSFATASI ACIDA TOTALE",
        "prezzo": 10.0,
        "cat": "Altro",
        "sintomi": [
            "controllo_fegato"
        ],
        "referto": "48-72h"
    },
    {
        "id": "fosfatasi-alcalina",
        "nome": "FOSFATASI ALCALINA",
        "prezzo": 3.8,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato"
        ],
        "referto": "48-72h"
    },
    {
        "id": "fosfatasi-alcalina-ossea-specifica",
        "nome": "FOSFATASI ALCALINA OSSEA SPECIFICA",
        "prezzo": 35.0,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato"
        ],
        "referto": "48-72h"
    },
    {
        "id": "fosfatasi-prostatica-pap",
        "nome": "FOSFATASI PROSTATICA (PAP)",
        "prezzo": 35.0,
        "cat": "Altro",
        "sintomi": [
            "controllo_fegato"
        ],
        "referto": "48-72h"
    },
    {
        "id": "fosfaturia-urine-24h",
        "nome": "FOSFATURIA URINE 24H",
        "prezzo": 3.8,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "fosforo",
        "nome": "FOSFORO",
        "prezzo": 2.8,
        "cat": "Elettroliti",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "fragola-ige-specifiche",
        "nome": "FRAGOLA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "frammentazione-dna",
        "nome": "FRAMMENTAZIONE DNA",
        "prezzo": 250.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "frassino-fraxinus-species-ige-specifiche",
        "nome": "FRASSINO (FRAXINUS SPECIES) (IgE SPECIFICHE)",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "free-beta-hcg-per-bitest",
        "nome": "FREE BETA HCG per BITEST",
        "prezzo": 8.2,
        "cat": "Ormoni",
        "sintomi": [
            "gravidanza"
        ],
        "referto": "48-72h",
        "urgente": true
    },
    {
        "id": "fruttosamina",
        "nome": "FRUTTOSAMINA",
        "prezzo": 15.0,
        "cat": "Glicemia/Diabete",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "funghi-champignon-ige-specifiche",
        "nome": "FUNGHI CHAMPIGNON (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "fusarium-moniliforme-ige-specifiche",
        "nome": "FUSARIUM MONILIFORME (IgE SPECIFICHE)",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "g6pd-analisi-genetica",
        "nome": "G6PD ANALISI GENETICA",
        "prezzo": 690.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "7-15gg"
    },
    {
        "id": "gad-65-anticorpi-anti-decarbossilasi-dell-acido-gl",
        "nome": "GAD 65 (ANTICORPI ANTI-DECARBOSSILASI DELL'ACIDO GLUTAMICO)",
        "prezzo": 65.2,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "gal-d1-ige-specifiche-ovomucoide",
        "nome": "Gal d1 IgE Specifiche (ovomucoide)",
        "prezzo": 122.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "gal-d2-ige-specifiche-ovoalbumina",
        "nome": "Gal d2 IgE Specifiche (ovoalbumina)",
        "prezzo": 12.5,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "gambero-ige-specifiche",
        "nome": "GAMBERO (IgE SPECIFICHE)",
        "prezzo": 18.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "gamma-glutamiltransferasi",
        "nome": "GAMMA GLUTAMILTRANSFERASI",
        "prezzo": 2.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "gastrina",
        "nome": "GASTRINA",
        "prezzo": 15.6,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "gastropanel",
        "nome": "GASTROPANEL",
        "prezzo": 180.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "gelso-bianco-morus-alba-ige-specifiche",
        "nome": "GELSO BIANCO (MORUS ALBA) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "gene-fattore-ii-protrombina-ricerca-della-mutazion",
        "nome": "GENE FATTORE II (PROTROMBINA): RICERCA DELLA MUTAZIONE G20210A",
        "prezzo": 98.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "gene-jak2-identificazione-qualitativa-di-v617f",
        "nome": "GENE JAK2 : IDENTIFICAZIONE QUALITATIVA DI V617F",
        "prezzo": 240.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "gene-pai-1-ricerca-della-variazione-4g-5g",
        "nome": "Gene PAI-1 Ricerca della variazione 4G/5G",
        "prezzo": 98.3,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "giallone-vespula-species-ige-specifiche",
        "nome": "GIALLONE (VESPULA SPECIES) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Infiammazione",
        "sintomi": [
            "dimagrimento",
            "dolori_articolari",
            "allergie",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "giardia-intestinalis-ricerca-antigene-nelle-feci",
        "nome": "GIARDIA INTESTINALIS RICERCA ANTIGENE NELLE FECI",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "ginepro-sabina-juniperus-sabinoides-ige-specifiche",
        "nome": "GINEPRO SABINA (JUNIPERUS SABINOIDES) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "glicosuria",
        "nome": "GLICOSURIA",
        "prezzo": 3.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "glucagone",
        "nome": "GLUCAGONE",
        "prezzo": 75.4,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "glucosio",
        "nome": "GLUCOSIO",
        "prezzo": 1.99,
        "cat": "Glicemia/Diabete",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "dimagrimento",
            "gravidanza"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "A digiuno da 8-12 ore"
    },
    {
        "id": "glucosio-0-60-120",
        "nome": "GLUCOSIO 0'60'120'",
        "prezzo": 35.0,
        "cat": "Glicemia/Diabete",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "dimagrimento",
            "gravidanza"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "A digiuno da 8-12 ore"
    },
    {
        "id": "glucosio-6-fosfatodeidrogenasi-g-6-pdh-eritrocitar",
        "nome": "GLUCOSIO-6-FOSFATODEIDROGENASI (G-6-PDH) ERITROCITARIA",
        "prezzo": 13.0,
        "cat": "Ematologia",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "dimagrimento",
            "gravidanza"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "A digiuno da 8-12 ore"
    },
    {
        "id": "glutammato-deidrogenasi-clostridium-difficile-gdh",
        "nome": "GLUTAMMATO DEIDROGENASI (CLOSTRIDIUM  DIFFICILE GDH)",
        "prezzo": 21.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "glutatione-perossidasi",
        "nome": "GLUTATIONE PEROSSIDASI",
        "prezzo": 73.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "glutatione-sangue-intero",
        "nome": "GLUTATIONE SANGUE INTERO",
        "prezzo": 60.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "glutine-ige-specifiche",
        "nome": "GLUTINE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "glycyphagus-domesticus-ige-specifiche",
        "nome": "GLYCYPHAGUS DOMESTICUS (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "gramigna-dei-prati-poa-pratensis-ige-specifiche",
        "nome": "GRAMIGNA DEI PRATI (POA PRATENSIS) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "granchio-ige-specifiche",
        "nome": "GRANCHIO (IgE SPECIFICHE)",
        "prezzo": 18.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "grano-ige-specifiche",
        "nome": "GRANO (IgE SPECIFICHE)",
        "prezzo": 14.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "grano-triticum-sativum-ige-specifiche",
        "nome": "GRANO (TRITICUM SATIVUM) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "grano-saraceno-ige-specifiche",
        "nome": "GRANO SARACENO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "gruppo-sanguigno-fattore-rh",
        "nome": "GRUPPO SANGUIGNO FATTORE RH",
        "prezzo": 8.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "hb-emoglobine-anomale-hbs-hbd-hbh-ecc",
        "nome": "HB EMOGLOBINE ANOMALE (HBS, HBD, HBH, ECC)",
        "prezzo": 15.0,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "hbsag-test-di-conferma",
        "nome": "HBsAg - TEST DI CONFERMA",
        "prezzo": 22.0,
        "cat": "Infettivologia",
        "sintomi": [
            "gravidanza",
            "controllo_fegato"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "hbsag-antigene-australia",
        "nome": "HBsAg (ANTIGENE AUSTRALIA)",
        "prezzo": 10.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "controllo_fegato",
            "allergie"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "hbsag-antigene-di-superficie-virus-epatite-b-quant",
        "nome": "HBSAG (ANTIGENE DI SUPERFICIE VIRUS EPATITE B) QUANTITATIVO",
        "prezzo": 41.0,
        "cat": "Epatico",
        "sintomi": [
            "gravidanza",
            "controllo_fegato",
            "allergie"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "hbsag-ultra",
        "nome": "HBsAg ULTRA",
        "prezzo": 25.0,
        "cat": "Infettivologia",
        "sintomi": [
            "gravidanza",
            "controllo_fegato"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "hbv-dna-genotipo",
        "nome": "HBV DNA Genotipo",
        "prezzo": 245.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "hbv-dna-quantitativo",
        "nome": "HBV DNA QUANTITATIVO",
        "prezzo": 75.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "hcv-rna-genotipo",
        "nome": "HCV RNA GENOTIPO",
        "prezzo": 157.3,
        "cat": "Infettivologia",
        "sintomi": [
            "controllo_fegato"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "he4-ovarian-cancer-marker",
        "nome": "HE4 (OVARIAN CANCER MARKER)",
        "prezzo": 95.0,
        "cat": "Tumore/Markers",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "helicobacter-pylori-ricerca-antigene-nelle-feci",
        "nome": "HELICOBACTER PYLORI RICERCA ANTIGENE NELLE FECI",
        "prezzo": 12.9,
        "cat": "Autoimmunità",
        "sintomi": [
            "problemi_digestivi",
            "allergie"
        ],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "hiv-1-rna-quantitativo",
        "nome": "HIV 1 RNA QUANTITATIVO",
        "prezzo": 157.3,
        "cat": "Infettivologia",
        "sintomi": [
            "gravidanza"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "hiv-1-2-riba-test-di-conferma",
        "nome": "HIV 1/2 RIBA - TEST DI CONFERMA",
        "prezzo": 144.2,
        "cat": "Infettivologia",
        "sintomi": [
            "gravidanza"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "hiv-anticorpi-antigene-p24",
        "nome": "HIV ANTICORPI - ANTIGENE P24",
        "prezzo": 100.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "allergie"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "hiv-anticorpo-antigene",
        "nome": "HIV ANTICORPO/ANTIGENE",
        "prezzo": 40.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "allergie"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "hla-locus-b51-tipizzazione",
        "nome": "HLA (locus B51) Tipizzazione",
        "prezzo": 85.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "hla-b27-dna",
        "nome": "HLA B27 DNA",
        "prezzo": 120.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "hla-classe-1-locus-a-b-c-classe-ii-dq-e-dr",
        "nome": "HLA CLASSE 1 ( LOCUS A,B,C) CLASSE II DQ E DR",
        "prezzo": 400.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "hla-per-identificazione-dq2-e-dq8",
        "nome": "HLA PER IDENTIFICAZIONE DQ2 E DQ8",
        "prezzo": 138.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "hla-tipo-c",
        "nome": "HLA TIPO C",
        "prezzo": 120.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "hollister-stier-labs-ige-specifiche",
        "nome": "HOLLISTER - STIER LABS. (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "hpv-dna-screening-e-tipizzazione-di-ceppi-al-alto-",
        "nome": "HPV DNA  SCREENING E TIPIZZAZIONE DI CEPPI AL ALTO RISCHIO ONCOGENO",
        "prezzo": 90.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "hpv-test-su-liquido-seminale",
        "nome": "Hpv test su liquido seminale",
        "prezzo": 95.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "hsv-1-2-tampone-vaginale",
        "nome": "HSV 1-2  Tampone vaginale",
        "prezzo": 60.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ia2-insulinoma-antigene-2-abs",
        "nome": "IA2 (Insulinoma Antigene 2) Abs",
        "prezzo": 63.0,
        "cat": "Glicemia/Diabete",
        "sintomi": [
            "aumento_peso",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "idrossilasi",
        "nome": "IDROSSILASI",
        "prezzo": 95.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "idrossipirene-urinario",
        "nome": "IDROSSIPIRENE URINARIO",
        "prezzo": 50.0,
        "cat": "Urinario",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "idrossipirene-urine-f-t",
        "nome": "IDROSSIPIRENE URINE F.T.",
        "prezzo": 43.6,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "idrossiprolina-urine-24h",
        "nome": "IDROSSIPROLINA URINE 24H",
        "prezzo": 24.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "iga-salivari",
        "nome": "IGA SALIVARI",
        "prezzo": 29.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ige-frumento",
        "nome": "IGE FRUMENTO",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ige-pannello-allergologico",
        "nome": "IGE PANNELLO ALLERGOLOGICO",
        "prezzo": 170.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ige-totali",
        "nome": "IgE TOTALI",
        "prezzo": 15.2,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "igf-bp-3",
        "nome": "IGF BP-3",
        "prezzo": 67.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "immunocomplessi-circolanti-cic",
        "nome": "IMMUNOCOMPLESSI CIRCOLANTI (CIC)",
        "prezzo": 15.4,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "immunofissazione-sierica",
        "nome": "IMMUNOFISSAZIONE SIERICA",
        "prezzo": 60.2,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "immunofissazione-urinaria",
        "nome": "IMMUNOFISSAZIONE URINARIA",
        "prezzo": 110.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "immunoglobuline-iga",
        "nome": "IMMUNOGLOBULINE IgA",
        "prezzo": 6.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "immunoglobuline-igg",
        "nome": "IMMUNOGLOBULINE IgG",
        "prezzo": 6.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "immunoglobuline-igg4",
        "nome": "IMMUNOGLOBULINE IGG4",
        "prezzo": 32.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "immunoglobuline-igm",
        "nome": "IMMUNOGLOBULINE IgM",
        "prezzo": 6.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "indicano-disbiosi-test",
        "nome": "INDICANO (Disbiosi TEST)",
        "prezzo": 45.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "indice-r-o-m-a",
        "nome": "INDICE R.O.M.A.",
        "prezzo": 50.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "indice-homa",
        "nome": "INDICE HOMA",
        "prezzo": 20.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "influenza-rapid-test",
        "nome": "Influenza RAPID TEST",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "inibina-b",
        "nome": "INIBINA B",
        "prezzo": 98.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "insulinemia",
        "nome": "INSULINEMIA",
        "prezzo": 5.5,
        "cat": "Glicemia/Diabete",
        "sintomi": [
            "aumento_peso"
        ],
        "referto": "48-72h"
    },
    {
        "id": "interleuchina-6",
        "nome": "INTERLEUCHINA 6",
        "prezzo": 235.0,
        "cat": "Infiammazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "intolleranza-al-nichel-ricerca-di-mutazioni-su-tnf",
        "nome": "Intolleranza al nichel (ricerca di mutazioni su TNF e FLG)",
        "prezzo": 90.0,
        "cat": "Infiammazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "intolleranza-genetica-al-lattosio-e-predisposizion",
        "nome": "INTOLLERANZA GENETICA AL LATTOSIO E PREDISPOSIZIONE ALLA MALATTIA CELIACA",
        "prezzo": 155.0,
        "cat": "Altro",
        "sintomi": [
            "problemi_digestivi"
        ],
        "referto": "7-15gg"
    },
    {
        "id": "iodio-sierico-totale",
        "nome": "IODIO SIERICO TOTALE",
        "prezzo": 230.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "iodio-urine-24h",
        "nome": "IODIO URINE 24H",
        "prezzo": 230.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "isocianato-hdi-ige-specifiche",
        "nome": "ISOCIANATO HDI (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "isocianato-mdi-ige-specifiche",
        "nome": "ISOCIANATO MDI (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "isocianato-tdi-ige-specifiche",
        "nome": "ISOCIANATO TDI (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "isoenzimi-ck-creatinchinasi",
        "nome": "Isoenzimi CK(Creatinchinasi)",
        "prezzo": 65.0,
        "cat": "Renale",
        "sintomi": [
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "renale"
    },
    {
        "id": "istamina",
        "nome": "ISTAMINA",
        "prezzo": 96.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "istamina-urine-24h",
        "nome": "ISTAMINA URINE 24H",
        "prezzo": 124.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "istologia-apparato-urogenitale-polipectomia-endoce",
        "nome": "ISTOLOGIA APPARATO UROGENITALE - POLIPECTOMIA ENDOCERVICALE",
        "prezzo": 150.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "istologia-cute-e-o-tessuti-molli-biopsia-escission",
        "nome": "ISTOLOGIA CUTE E/O TESSUTI MOLLI - BIOPSIA ESCISSIONALE",
        "prezzo": 50.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "jack-2",
        "nome": "JACK-2",
        "prezzo": 130.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "jak-2",
        "nome": "Jak-2",
        "prezzo": 130.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "kir-affinitymap",
        "nome": "KIR Affinitymap",
        "prezzo": 235.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "kir-affinitymap-hla-c",
        "nome": "KIR Affinitymap + HLA-C",
        "prezzo": 400.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "kiwi-ige-specifiche",
        "nome": "KIWI (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "kwikpen-2-5-mg-mj-pack-obesita",
        "nome": "KWIKPEN 2.5 MG MJ PACK OBESITA'",
        "prezzo": 346.58,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "lac-lupus-anticoagulant",
        "nome": "LAC (LUPUS ANTICOAGULANT)",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "lamotrigina",
        "nome": "LAMOTRIGINA",
        "prezzo": 23.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "lanciuola-plantago-lanceolata-ige-specifiche",
        "nome": "LANCIUOLA (PLANTAGO LANCEOLATA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "latte-bollito-ige-specifiche",
        "nome": "LATTE BOLLITO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "latte-vaccino-ige-specifiche",
        "nome": "LATTE Vaccino (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "lattice-ige-specifiche",
        "nome": "LATTICE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "latticodeidrogenasi-ldh",
        "nome": "LATTICODEIDROGENASI (LDH)",
        "prezzo": 2.1,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "lattoalbumina-di-mucca-ige-specifiche",
        "nome": "LATTOALBUMINA DI MUCCA (igE specifiche)",
        "prezzo": 15.0,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "lattoferrina-fecale",
        "nome": "LATTOFERRINA FECALE",
        "prezzo": 65.9,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "lattuga-ige-specifiche",
        "nome": "LATTUGA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ldl-ossidate",
        "nome": "LDL OSSIDATE",
        "prezzo": 95.0,
        "cat": "Lipidico",
        "sintomi": [
            "controllo_cuore"
        ],
        "referto": "48-72h",
        "upsell": "cardio"
    },
    {
        "id": "lenticchia-ige-specifiche",
        "nome": "LENTICCHIA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "lepidoglyphus-destructor-ige-specifiche",
        "nome": "LEPIDOGLYPHUS DESTRUCTOR (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "leptina",
        "nome": "LEPTINA",
        "prezzo": 100.2,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "levetiracetam-keppra",
        "nome": "LEVETIRACETAM (KEPPRA)",
        "prezzo": 65.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "lievito-acido-naturale-ige-specifiche",
        "nome": "LIEVITO ACIDO NATURALE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ligustro-ligustrum-vulgare-ige-specifiche",
        "nome": "LIGUSTRO (LIGUSTRUM VULGARE) (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "limone-ige-specifiche",
        "nome": "LIMONE (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "lipasi",
        "nome": "LIPASI",
        "prezzo": 4.6,
        "cat": "Altro",
        "sintomi": [
            "problemi_digestivi"
        ],
        "referto": "48-72h"
    },
    {
        "id": "lipoproteina-a",
        "nome": "LIPOPROTEINA A",
        "prezzo": 20.0,
        "cat": "Lipidico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "lipoproteine-profilo-lipoprint",
        "nome": "Lipoproteine Profilo LIPOPRINT",
        "prezzo": 260.0,
        "cat": "Lipidico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "lisozima",
        "nome": "LISOZIMA",
        "prezzo": 60.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "litio",
        "nome": "LITIO",
        "prezzo": 8.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "loglierella-lolium-perenne-ige-specifiche",
        "nome": "LOGLIERELLA (LOLIUM PERENNE) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "macroprolattina",
        "nome": "MACROPROLATTINA",
        "prezzo": 250.0,
        "cat": "Ormoni",
        "sintomi": [
            "infertilita"
        ],
        "referto": "48-72h",
        "prep": "A riposo, evitare stress"
    },
    {
        "id": "mad-x-fox",
        "nome": "MAD X FOX",
        "prezzo": 350.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "magnesio",
        "nome": "MAGNESIO",
        "prezzo": 3.7,
        "cat": "Elettroliti",
        "sintomi": [
            "insonnia",
            "ansia_stress",
            "palpitazioni"
        ],
        "referto": "48-72h"
    },
    {
        "id": "magnesio-eritrocitario",
        "nome": "MAGNESIO ERITROCITARIO",
        "prezzo": 18.0,
        "cat": "Ematologia",
        "sintomi": [
            "insonnia",
            "ansia_stress",
            "palpitazioni"
        ],
        "referto": "48-72h"
    },
    {
        "id": "magnesio-urine-24h",
        "nome": "MAGNESIO URINE 24H",
        "prezzo": 6.3,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "palpitazioni",
            "insonnia",
            "controllo_reni",
            "ansia_stress"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "mais-ige-specifiche",
        "nome": "MAIS (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "malattia-del-rene-policistico-autonomia-recessiva",
        "nome": "MALATTIA DEL RENE POLICISTICO (autonomia recessiva)",
        "prezzo": 690.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "malattie-genetiche-14-ricerca-fibrosi-cistica-beta",
        "nome": "MALATTIE GENETICHE (14)- Ricerca Fibrosi Cistica, Beta Talassemia, Anemia Falciforme",
        "prezzo": 250.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "malto-ige-specifiche",
        "nome": "MALTO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Epatico",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "mandarino-ige-specifiche",
        "nome": "MANDARINO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "mandorla-ige-specifiche",
        "nome": "MANDORLA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "manganese-plasmatico",
        "nome": "MANGANESE PLASMATICO",
        "prezzo": 21.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "manganese-urine-f-t",
        "nome": "MANGANESE URINE F.T.",
        "prezzo": 27.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "manganese-urine-i-t",
        "nome": "MANGANESE URINE I.T.",
        "prezzo": 21.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "margherita-dei-prati-chrysantemum-leucanthemum-ige",
        "nome": "MARGHERITA DEI PRATI (CHRYSANTEMUM LEUCANTHEMUM) (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "mela-ige-specifiche",
        "nome": "MELA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "melanzana-ige-specifiche",
        "nome": "MELANZANA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "melone-ige-specifiche",
        "nome": "MELONE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "mercurio-urine-f-t",
        "nome": "MERCURIO URINE F.T.",
        "prezzo": 27.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "mercurio-urine-i-t",
        "nome": "MERCURIO URINE I.T.",
        "prezzo": 27.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "merluzzo-ige-specifiche",
        "nome": "MERLUZZO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "metabolismo-degli-zuccheri",
        "nome": "METABOLISMO DEGLI ZUCCHERI",
        "prezzo": 37.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "metaboliti-reattivi-dell-ossigeno-derivati-dei-rad",
        "nome": "METABOLITI REATTIVI DELL'OSSIGENO (DERIVATI DEI RADICALI LIBERI)",
        "prezzo": 40.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "metadone-test-di-conferma",
        "nome": "METADONE - TEST DI CONFERMA",
        "prezzo": 168.2,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "metaemoglobina",
        "nome": "METAEMOGLOBINA",
        "prezzo": 12.5,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "metanefrine-plasmatiche-libere",
        "nome": "METANEFRINE PLASMATICHE LIBERE",
        "prezzo": 40.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "metanefrine-urine-24h",
        "nome": "METANEFRINE URINE 24H",
        "prezzo": 35.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "metanolo-urine-f-t",
        "nome": "METANOLO URINE F.T.",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "metiletilchetone-mek-urine-f-t",
        "nome": "METILETILCHETONE (MEK) URINE F.T.",
        "prezzo": 20.2,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "metiletilchetone-mek-urine-i-t",
        "nome": "METILETILCHETONE (MEK) URINE I.T.",
        "prezzo": 20.2,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "metilisobutilchetone-mibk-urine-f-t",
        "nome": "METILISOBUTILCHETONE (MIBK) URINE F.T.",
        "prezzo": 50.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "microalbuminuria",
        "nome": "MICROALBUMINURIA",
        "prezzo": 6.8,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato",
            "controllo_reni"
        ],
        "referto": "48-72h"
    },
    {
        "id": "microalbuminuria-urine-24h",
        "nome": "MICROALBUMINURIA URINE 24H",
        "prezzo": 6.8,
        "cat": "Epatico",
        "sintomi": [
            "gravidanza",
            "controllo_fegato",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "miele-ige-specifiche",
        "nome": "MIELE (IgE SPECIFICHE)",
        "prezzo": 20.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "mioglobina",
        "nome": "MIOGLOBINA",
        "prezzo": 12.0,
        "cat": "Cardiologico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "mirtillo-ige-specifiche",
        "nome": "MIRTILLO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "misurazione-pressione-arteriosa",
        "nome": "MISURAZIONE PRESSIONE ARTERIOSA",
        "prezzo": 5.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "mitili-ige-specifiche",
        "nome": "MITILI (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "mix-graminacee",
        "nome": "MIX GRAMINACEE",
        "prezzo": 22.0,
        "cat": "Allergologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "modulo-03-esami-del-sangue-unisalute",
        "nome": "MODULO 03 ESAMI DEL SANGUE  UNISALUTE",
        "prezzo": 44.42,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "modulo-25-gruppo-14-esami-del-sangue-unisalute",
        "nome": "MODULO 25 (GRUPPO 14 ESAMI DEL SANGUE) UNISALUTE",
        "prezzo": 40.51,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "monometilformammide-mmf-urine-f-t",
        "nome": "MONOMETILFORMAMMIDE (MMF) URINE F.T.",
        "prezzo": 22.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "mono-test",
        "nome": "MONO-TEST",
        "prezzo": 18.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "mounjaro-7-5-mg-start-pack-progetto-slim-care-part",
        "nome": "Mounjaro 7,5 mg -Start Pack - progetto Slim Care - parte di prestazione sanitaria complessa",
        "prezzo": 395.45,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "mthfr1-c677t",
        "nome": "MTHFR1 C677T",
        "prezzo": 50.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "mucopolisaccaridosi-tipo-i-mps-i-analisi-del-gene-",
        "nome": "MUCOPOLISACCARIDOSI tipo I (MPS I) Analisi del gene IDUA",
        "prezzo": 690.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "48-72h"
    },
    {
        "id": "mucopolisaccaridosi-tipo-iii-b-analisi-del-gene-na",
        "nome": "MUCOPOLISACCARIDOSI tipo III B - Analisi del gene NAGLU",
        "prezzo": 690.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "48-72h"
    },
    {
        "id": "mucor-racemosus-ige-specifiche",
        "nome": "MUCOR RACEMOSUS (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "muffe-ige-specifiche",
        "nome": "MUFFE (IgE SPECIFICHE)",
        "prezzo": 18.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "mutazione-g20210a-del-fattore-ii",
        "nome": "Mutazione G20210A del Fattore II",
        "prezzo": 90.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "mybiome-analisi-molecolare-del-microbiota-intestin",
        "nome": "MYBIOME - ANALISI MOLECOLARE DEL MICROBIOTA INTESTINALE",
        "prezzo": 450.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "7-15gg"
    },
    {
        "id": "mycobacterium-tuberculosis-dna",
        "nome": "MYCOBACTERIUM TUBERCULOSIS DNA",
        "prezzo": 176.9,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "mycoplasma-genitalium-dna",
        "nome": "MYCOPLASMA GENITALIUM DNA",
        "prezzo": 80.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "neisseria-gonorrhoeae-esame-colturale-ricerca-su-l",
        "nome": "NEISSERIA GONORRHOEAE ESAME COLTURALE (ricerca su Liquido seminale)",
        "prezzo": 15.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "neisseria-gonorrhoeae-esame-colturale-urina",
        "nome": "NEISSERIA GONORRHOEAE ESAME COLTURALE (URINA)",
        "prezzo": 12.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "netilmicina",
        "nome": "NETILMICINA",
        "prezzo": 58.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "nichel-sierico",
        "nome": "NICHEL SIERICO",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "nichel-urinario-fine-turno",
        "nome": "NICHEL URINARIO fine turno",
        "prezzo": 15.0,
        "cat": "Urinario",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "nichel-urinario-inizio-turno",
        "nome": "NICHEL URINARIO inizio turno",
        "prezzo": 15.0,
        "cat": "Urinario",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "nickel-urine-f-t",
        "nome": "NICKEL URINE F.T.",
        "prezzo": 15.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "nickel-urine-i-t",
        "nome": "NICKEL URINE I.T.",
        "prezzo": 15.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "n-metilacetammide-urine-f-t",
        "nome": "N-METILACETAMMIDE URINE F.T.",
        "prezzo": 21.6,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "nocciola-ige-specifiche",
        "nome": "NOCCIOLA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "nocciolo-corylus-avellana-ige-specifiche",
        "nome": "NOCCIOLO (CORYLUS AVELLANA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "noce-ige-specifiche",
        "nome": "NOCE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "noce-brasiliana-ige-specifiche",
        "nome": "NOCE BRASILIANA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "noce-di-california-juglans-californica-ige-specifi",
        "nome": "NOCE DI CALIFORNIA (JUGLANS CALIFORNICA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "noce-di-cocco-ige-specifiche",
        "nome": "NOCE DI COCCO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "normetanefrine-urine-24h",
        "nome": "NORMETANEFRINE URINE 24H",
        "prezzo": 35.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "numero-di-dibucaina",
        "nome": "NUMERO DI DIBUCAINA",
        "prezzo": 6.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ogtt-curva-glicemica-in-gravidanza",
        "nome": "OGTT  - CURVA GLICEMICA IN GRAVIDANZA",
        "prezzo": 35.0,
        "cat": "Glicemia/Diabete",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "A digiuno da 8-12 ore"
    },
    {
        "id": "ogtt-curva-glicemica-in-gravidanza-arancia",
        "nome": "OGTT  - CURVA GLICEMICA IN GRAVIDANZA (ARANCIA)",
        "prezzo": 55.0,
        "cat": "Glicemia/Diabete",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "A digiuno da 8-12 ore"
    },
    {
        "id": "olivo-olea-europea-ige-specifiche",
        "nome": "OLIVO (OLEA EUROPEA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "olmo-ulmus-campestris-ige-specifiche",
        "nome": "OLMO (ULMUS CAMPESTRIS) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "omocisteina",
        "nome": "OMOCISTEINA",
        "prezzo": 28.5,
        "cat": "Cardiologico",
        "sintomi": [
            "controllo_cuore"
        ],
        "referto": "48-72h"
    },
    {
        "id": "omocisteina-dna-mthfr-c677t-a1298c",
        "nome": "OMOCISTEINA DNA (MTHFR) C677T + A1298C",
        "prezzo": 100.0,
        "cat": "Cardiologico",
        "sintomi": [
            "controllo_cuore"
        ],
        "referto": "48-72h"
    },
    {
        "id": "onco-advance-brca-pap-test",
        "nome": "Onco Advance  BRCA + PAP TEST",
        "prezzo": 520.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "onco-advance-plus-brca-pap-test",
        "nome": "Onco Advance Plus BRCA + Pap Test",
        "prezzo": 620.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "onco-advance-risk-breast-pap-test",
        "nome": "ONCO ADVANCE RISK BREAST + PAP TEST",
        "prezzo": 820.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "onco-advance-risk-lynch-pap-test",
        "nome": "ONCO ADVANCE RISK LYNCH + PAP TEST",
        "prezzo": 690.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "onco-advance-risk-ovarian-pap-test",
        "nome": "ONCO ADVANCE RISK OVARIAN + PAP TEST",
        "prezzo": 820.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "oncoadvance-risk-brca-analisi-dei-geni-brca1-e-brc",
        "nome": "OncoAdvance Risk BRCA - Analisi dei geni BRCA1 e BRCA2",
        "prezzo": 520.0,
        "cat": "Tumore/Markers",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ontano-alnus-incana-ige-specifiche",
        "nome": "ONTANO (ALNUS INCANA) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "oppiacei-test-di-conferma",
        "nome": "OPPIACEI - TEST DI CONFERMA",
        "prezzo": 168.2,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "origano-ige-specifiche",
        "nome": "ORIGANO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ormone-anti-mulleriano-amh",
        "nome": "ORMONE ANTI-MULLERIANO (AMH)",
        "prezzo": 55.0,
        "cat": "Altro",
        "sintomi": [
            "infertilita"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ormone-follicolo-stimolante-fsh",
        "nome": "ORMONE FOLLICOLO STIMOLANTE (FSH)",
        "prezzo": 16.9,
        "cat": "Ormoni",
        "sintomi": [
            "menopausa",
            "infertilita"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ormone-luteinizzante-lh",
        "nome": "ORMONE LUTEINIZZANTE (LH)",
        "prezzo": 9.0,
        "cat": "Ormoni",
        "sintomi": [
            "menopausa",
            "infertilita"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ormone-somatotropo-hgh",
        "nome": "ORMONE SOMATOTROPO (HGH)",
        "prezzo": 16.8,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ormone-tireotropo-tsh",
        "nome": "ORMONE TIREOTROPO (TSH)",
        "prezzo": 10.0,
        "cat": "Tiroide",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "perdita_capelli",
            "dimagrimento",
            "menopausa",
            "gravidanza",
            "palpitazioni",
            "insonnia",
            "infertilita",
            "ansia_stress"
        ],
        "referto": "48h",
        "upsell": "donna-under40"
    },
    {
        "id": "ornitina-su-plasma",
        "nome": "ORNITINA SU PLASMA",
        "prezzo": 110.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ornitina-urinaria",
        "nome": "ORNITINA URINARIA",
        "prezzo": 110.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ortica-urtica-dioica-ige-specifiche",
        "nome": "ORTICA (URTICA DIOICA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "orto-cresolo-urine-f-t",
        "nome": "ORTO-CRESOLO URINE F.T.",
        "prezzo": 20.1,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "orto-cresolo-urine-i-t",
        "nome": "ORTO-CRESOLO URINE I.T.",
        "prezzo": 20.1,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "orzo-ige-specifiche",
        "nome": "ORZO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "osmolarita-plasmatica",
        "nome": "OSMOLARITA' PLASMATICA",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ossalati-urine",
        "nome": "OSSALATI URINE",
        "prezzo": 30.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "osteocalcina",
        "nome": "OSTEOCALCINA",
        "prezzo": 36.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ostrica-ige-specifiche",
        "nome": "OSTRICA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "oxcarbazepina",
        "nome": "OXCARBAZEPINA",
        "prezzo": 19.2,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "pack-cardio-plus",
        "nome": "PACK CARDIO PLUS",
        "prezzo": 85.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "pack-donna-under-40",
        "nome": "Pack donna under 40",
        "prezzo": 106.42,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "pack-esami-percorso-obesit",
        "nome": "Pack Esami percorso Obesità",
        "prezzo": 70.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "pack-obesita-under-18",
        "nome": "PACK OBESITA UNDER 18",
        "prezzo": 130.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "pack-smart-base",
        "nome": "PACK SMART BASE",
        "prezzo": 22.47,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "pack-ultra-base",
        "nome": "Pack ultra base",
        "prezzo": 46.79,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "paleino-odoroso-anthoxanthum-odoratum-ige-specific",
        "nome": "PALEINO ODOROSO (ANTHOXANTHUM ODORATUM) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "paleo-bromus-inermis-ige-specifiche",
        "nome": "PALEO (BROMUS INERMIS) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "paleo-dei-prati-festuca-elatior-ige-specifiche",
        "nome": "PALEO DEI PRATI (FESTUCA ELATIOR) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "pannello-les-ss-lupus-eritematoso-sistemico-sindro",
        "nome": "PANNELLO LES/SS (LUPUS ERITEMATOSO SISTEMICO)/(SINDROME DI SJÖGREN)",
        "prezzo": 120.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "papaia-ige-specifiche",
        "nome": "PAPAIA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "papp-a-per-bitest",
        "nome": "PAPP-A per BITEST",
        "prezzo": 8.3,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "parassita-malarico-ricerca-antigenica",
        "nome": "PARASSITA MALARICO RICERCA ANTIGENICA",
        "prezzo": 125.1,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "parmigiano-ige-specifiche",
        "nome": "PARMIGIANO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "paroxetina",
        "nome": "PAROXETINA",
        "prezzo": 229.6,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "parvovirus-b19-dna",
        "nome": "PARVOVIRUS B19 DNA",
        "prezzo": 100.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "patata-ige-specifiche",
        "nome": "PATATA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "pcr-alta-sensibilita",
        "nome": "PCR ALTA SENSIBILITA'",
        "prezzo": 22.0,
        "cat": "Epatico",
        "sintomi": [
            "dolori_articolari",
            "controllo_cuore",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "penicillina-g-ige-specifiche",
        "nome": "PENICILLINA G - IGE Specifiche",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "penicillina-v-ige-specifiche",
        "nome": "PENICILLINA V - IGE Specifiche",
        "prezzo": 25.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "penicillium-notatum-ige-specifiche",
        "nome": "PENICILLIUM NOTATUM (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "pepe-nero-ige-specifiche",
        "nome": "PEPE NERO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "pepe-verde-ige-specifiche",
        "nome": "PEPE VERDE (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "peperone-ige-specifiche",
        "nome": "PEPERONE (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "pera-ige-specifiche",
        "nome": "PERA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "percentuale-di-saturazione-di-transferrina",
        "nome": "PERCENTUALE DI SATURAZIONE DI TRANSFERRINA",
        "prezzo": 3.0,
        "cat": "Ematologia",
        "sintomi": [
            "anemia"
        ],
        "referto": "48-72h"
    },
    {
        "id": "percloroetilene-ematico",
        "nome": "PERCLOROETILENE EMATICO",
        "prezzo": 19.9,
        "cat": "Elettroliti",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "percloroetilene-urine-f-t",
        "nome": "PERCLOROETILENE URINE F.T.",
        "prezzo": 19.9,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "percloroetilene-urine-i-t",
        "nome": "PERCLOROETILENE URINE I.T.",
        "prezzo": 19.9,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "pesca-ige-specifiche",
        "nome": "PESCA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ph-ematico",
        "nome": "PH EMATICO",
        "prezzo": 11.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "phenobarbital-gardenale",
        "nome": "PHENOBARBITAL (GARDENALE)",
        "prezzo": 22.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "pino-pinus-strobus-ige-specifiche",
        "nome": "PINO (PINUS STROBUS) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "pinolo-ige-specifiche",
        "nome": "PINOLO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "piombemia",
        "nome": "PIOMBEMIA",
        "prezzo": 22.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "piombo-urine-f-t",
        "nome": "PIOMBO URINE F.T.",
        "prezzo": 11.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "piombo-urine-i-t",
        "nome": "PIOMBO URINE I.T.",
        "prezzo": 11.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "pioppo-populos-deltoides-ige-specifiche",
        "nome": "PIOPPO (POPULOS DELTOIDES) (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "piruvatochinasi-eritrocitaria",
        "nome": "PIRUVATOCHINASI ERITROCITARIA",
        "prezzo": 67.9,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "pisello-ige-specifiche",
        "nome": "PISELLO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "pistacchio-ige-specifiche",
        "nome": "PISTACCHIO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "piume-d-anatra-ige-specifiche",
        "nome": "PIUME D'ANATRA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "piume-di-canarino-ige-specifiche",
        "nome": "PIUME DI CANARINO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari",
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "piume-di-gallina-ige-specifiche",
        "nome": "PIUME DI GALLINA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "piume-d-oca-ige-specifiche",
        "nome": "PIUME D'OCA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "plasminogeno",
        "nome": "PLASMINOGENO",
        "prezzo": 30.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "platano-platanus-acerifolia-ige-specifiche",
        "nome": "PLATANO (PLATANUS ACERIFOLIA) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "platessa-ige-specifiche",
        "nome": "PLATESSA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "pol-d5-polistes-dominulus",
        "nome": "POL D5 POLISTES DOMINULUS",
        "prezzo": 19.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "polipeptide-pancreatico",
        "nome": "POLIPEPTIDE PANCREATICO",
        "prezzo": 115.4,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "polpo-ige-specifiche",
        "nome": "POLPO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "polvere-di-casa-ige-specifiche",
        "nome": "POLVERE DI CASA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "polvere-di-grano-ige-specifiche",
        "nome": "POLVERE DI GRANO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "pomodoro-ige-specifiche",
        "nome": "POMODORO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "pompelmo-ige-specifiche",
        "nome": "POMPELMO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "porfirine-totali-urine-24h",
        "nome": "PORFIRINE TOTALI URINE 24H",
        "prezzo": 48.2,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "potassio",
        "nome": "POTASSIO",
        "prezzo": 4.8,
        "cat": "Elettroliti",
        "sintomi": [
            "palpitazioni"
        ],
        "referto": "48-72h"
    },
    {
        "id": "potassio-urine-24h",
        "nome": "POTASSIO URINE 24H",
        "prezzo": 3.7,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni",
            "palpitazioni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "potenziale-biologico-antiossidante-bap",
        "nome": "POTENZIALE BIOLOGICO ANTIOSSIDANTE (BAP)",
        "prezzo": 35.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "prealbumina",
        "nome": "PREALBUMINA",
        "prezzo": 9.0,
        "cat": "Epatico",
        "sintomi": [
            "controllo_fegato"
        ],
        "referto": "48-72h"
    },
    {
        "id": "prelievo-a-domicilio",
        "nome": "Prelievo a domicilio",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "prelievo-microbiologico",
        "nome": "PRELIEVO MICROBIOLOGICO",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "prelievo-venoso",
        "nome": "PRELIEVO VENOSO",
        "prezzo": 3.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "prelievo-venoso",
        "nome": "PRELIEVO VENOSO",
        "prezzo": 3.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "prezzemolo-ige-specifiche",
        "nome": "PREZZEMOLO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "primidone",
        "nome": "PRIMIDONE",
        "prezzo": 17.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "probnp",
        "nome": "ProBNP",
        "prezzo": 51.0,
        "cat": "Cardiologico",
        "sintomi": [
            "controllo_cuore",
            "palpitazioni"
        ],
        "referto": "48-72h",
        "upsell": "cardio"
    },
    {
        "id": "procalcitonina",
        "nome": "PROCALCITONINA",
        "prezzo": 34.0,
        "cat": "Tiroide",
        "sintomi": [],
        "referto": "48-72h",
        "upsell": "tiroide-plus",
        "urgente": true
    },
    {
        "id": "prodotti-degradazione-fibrinogeno-fdp",
        "nome": "PRODOTTI DEGRADAZIONE FIBRINOGENO (FDP)",
        "prezzo": 100.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "profilo-anticorpi-anti-msa-anticorpi-miosite-speci",
        "nome": "PROFILO ANTICORPI ANTI MSA (Anticorpi miosite specifici)",
        "prezzo": 145.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "profilo-glicemico",
        "nome": "PROFILO GLICEMICO",
        "prezzo": 3.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "profilo-remautologico",
        "nome": "PROFILO REMAUTOLOGICO",
        "prezzo": 102.9,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "profilo-trombofilico-autoanticorpi",
        "nome": "Profilo Trombofilico Autoanticorpi",
        "prezzo": 411.3,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "progesterone",
        "nome": "PROGESTERONE",
        "prezzo": 8.5,
        "cat": "Ormoni",
        "sintomi": [
            "infertilita"
        ],
        "referto": "48-72h"
    },
    {
        "id": "prolattina",
        "nome": "PROLATTINA",
        "prezzo": 10.0,
        "cat": "Ormoni",
        "sintomi": [
            "infertilita"
        ],
        "referto": "48-72h",
        "prep": "A riposo, evitare stress"
    },
    {
        "id": "prolattina-curva",
        "nome": "PROLATTINA CURVA",
        "prezzo": 7.5,
        "cat": "Ormoni",
        "sintomi": [
            "infertilita"
        ],
        "referto": "48-72h",
        "prep": "A riposo, evitare stress"
    },
    {
        "id": "propeptide-amino-terminale-del-procollagene-tipo-1",
        "nome": "PROPEPTIDE AMINO-TERMINALE DEL PROCOLLAGENE TIPO 1 (P1NP)",
        "prezzo": 45.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "proteina-c-coagulativa",
        "nome": "proteina C COAGULATIVA",
        "prezzo": 11.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "proteina-c-funzionale",
        "nome": "PROTEINA C FUNZIONALE",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "proteina-c-reattiva-pcr",
        "nome": "PROTEINA C REATTIVA (PCR)",
        "prezzo": 4.6,
        "cat": "Infiammazione",
        "sintomi": [
            "dolori_articolari",
            "controllo_cuore",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "proteina-legante-il-retinolo",
        "nome": "Proteina Legante il Retinolo",
        "prezzo": 22.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "proteina-s-libera",
        "nome": "PROTEINA S LIBERA",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "proteine-totali",
        "nome": "PROTEINE TOTALI",
        "prezzo": 5.4,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "proteine-totali-urine-24h",
        "nome": "PROTEINE TOTALI URINE 24H",
        "prezzo": 3.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "proteinuria-di-bence-jones",
        "nome": "PROTEINURIA DI BENCE-JONES",
        "prezzo": 28.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "prugna-ige-specifiche",
        "nome": "PRUGNA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "psa-libero-free-psa",
        "nome": "PSA LIBERO (FREE-PSA)",
        "prezzo": 12.0,
        "cat": "Tumore/Markers",
        "sintomi": [
            "controllo_prostata"
        ],
        "referto": "48-72h",
        "upsell": "uomo-under40"
    },
    {
        "id": "psa-reflex",
        "nome": "PSA REFLEX",
        "prezzo": 22.0,
        "cat": "Tumore/Markers",
        "sintomi": [
            "controllo_prostata"
        ],
        "referto": "48-72h",
        "upsell": "uomo-under40"
    },
    {
        "id": "pth-intatto-paratormone",
        "nome": "PTH INTATTO (PARATORMONE)",
        "prezzo": 12.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h",
        "upsell": "donna-over40"
    },
    {
        "id": "quantiferon",
        "nome": "QUANTIFERON",
        "prezzo": 130.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "quercia-bianca-quercus-alba-ige-specifiche",
        "nome": "QUERCIA BIANCA (QUERCUS ALBA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "rame-urine-24-ore",
        "nome": "RAME URINE 24 ORE",
        "prezzo": 12.9,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "rame-urine-f-t",
        "nome": "RAME URINE F.T.",
        "prezzo": 9.9,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "raschiamento-ungueale-dito-del-piede",
        "nome": "RASCHIAMENTO UNGUEALE (dito del piede)",
        "prezzo": 30.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "raschiamento-ungueale-dito-mano-dx",
        "nome": "RASCHIAMENTO UNGUEALE (dito mano DX)",
        "prezzo": 20.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "rast-toxocara-toxocara-canis",
        "nome": "RAST TOXOCARA (TOXOCARA CANIS)",
        "prezzo": 18.5,
        "cat": "Epatico",
        "sintomi": [
            "gravidanza",
            "allergie"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "reagente-lactate-dehydrogenase-ldh",
        "nome": "REAGENTE LACTATE DEHYDROGENASE (LDH)",
        "prezzo": 4.9,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "recettore-solubile-della-transferrina",
        "nome": "RECETTORE SOLUBILE DELLA TRANSFERRINA",
        "prezzo": 43.0,
        "cat": "Ematologia",
        "sintomi": [
            "anemia"
        ],
        "referto": "48-72h"
    },
    {
        "id": "recettori-interleuchina-2",
        "nome": "RECETTORI INTERLEUCHINA 2",
        "prezzo": 155.0,
        "cat": "Infiammazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "renina-ortostatismo",
        "nome": "RENINA (ORTOSTATISMO)",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "resistenza-alla-proteina-c-attivata-apc-r",
        "nome": "RESISTENZA ALLA PROTEINA C ATTIVATA (APC-R)",
        "prezzo": 20.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "resistenza-osmotica-eritrocitaria-simmel",
        "nome": "RESISTENZA OSMOTICA  ERITROCITARIA (SIMMEL)",
        "prezzo": 28.0,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "resistenza-osmotica-eritrocitaria-globulare-r-o-e-",
        "nome": "RESISTENZA OSMOTICA ERITROCITARIA/GLOBULARE (R.O.E./R.O.G.)",
        "prezzo": 27.6,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "reticolociti",
        "nome": "RETICOLOCITI",
        "prezzo": 12.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "reuma-test-fattore-reumatoide",
        "nome": "REUMA TEST (FATTORE REUMATOIDE)",
        "prezzo": 7.2,
        "cat": "Autoimmunità",
        "sintomi": [
            "dolori_articolari"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-mycoplasmi-e-ureaplasmi-tampone-vaginale",
        "nome": "RICERCA  MYCOPLASMI E UREAPLASMI TAMPONE VAGINALE",
        "prezzo": 18.5,
        "cat": "Renale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-ag-chlamydia",
        "nome": "RICERCA Ag CHLAMYDIA",
        "prezzo": 8.5,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "ricerca-antigene-legionella",
        "nome": "Ricerca antigene Legionella",
        "prezzo": 62.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-asbesto-e-siderociti",
        "nome": "RICERCA ASBESTO E SIDEROCITI",
        "prezzo": 36.4,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-campylobacter-su-feci",
        "nome": "Ricerca Campylobacter su feci",
        "prezzo": 22.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "ricerca-candida-nelle-feci",
        "nome": "RICERCA CANDIDA NELLE FECI",
        "prezzo": 25.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "ricerca-dna-chlamydia-trachomatis-su-liquido-semin",
        "nome": "RICERCA DNA CHLAMYDIA TRACHOMATIS SU LIQUIDO SEMINALE",
        "prezzo": 70.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "ricerca-dna-chlamydia-trachomatis-su-tampone-cervi",
        "nome": "RICERCA DNA CHLAMYDIA TRACHOMATIS SU TAMPONE CERVICALE",
        "prezzo": 70.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "ricerca-dna-chlamydia-trachomatis-su-tampone-uretr",
        "nome": "RICERCA DNA CHLAMYDIA TRACHOMATIS SU TAMPONE URETRALE",
        "prezzo": 70.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "ricerca-dna-chlamydia-trachomatis-su-tampone-vagin",
        "nome": "RICERCA DNA CHLAMYDIA TRACHOMATIS SU TAMPONE VAGINALE",
        "prezzo": 70.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "ricerca-dna-chlamydia-trachomatis-su-urine",
        "nome": "RICERCA DNA CHLAMYDIA TRACHOMATIS SU URINE",
        "prezzo": 70.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "ricerca-dna-neisseria-gonorrhoeae",
        "nome": "RICERCA DNA NEISSERIA GONORRHOEAE",
        "prezzo": 70.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-gardnerella-vaginalis-in-liquido-seminale",
        "nome": "RICERCA Gardnerella vaginalis in Liquido Seminale",
        "prezzo": 20.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-hsv-1-2-tampone-labiale",
        "nome": "RICERCA HSV 1-2  Tampone labiale",
        "prezzo": 50.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-micoplasmi-liquido-seminale",
        "nome": "RICERCA MICOPLASMI LIQUIDO SEMINALE",
        "prezzo": 40.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-micoplasmi-nelle-urine",
        "nome": "RICERCA MICOPLASMI NELLE URINE",
        "prezzo": 35.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "ricerca-micoplasmi-tampone-uretrale",
        "nome": "RICERCA MICOPLASMI TAMPONE URETRALE",
        "prezzo": 12.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-mycoplasma-e-ureaplasma-tampone-endometria",
        "nome": "RICERCA MYCOPLASMA E UREAPLASMA TAMPONE ENDOMETRIALE",
        "prezzo": 15.0,
        "cat": "Renale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-mycoplasmi-e-ureaplasmi-in-liquido-seminal",
        "nome": "RICERCA MYCOPLASMI e UREAPLASMI in Liquido Seminale",
        "prezzo": 40.0,
        "cat": "Renale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-mycoplasmi-e-ureaplasmi-tampone-cervicale",
        "nome": "RICERCA MYCOPLASMI e UREAPLASMI TAMPONE CERVICALE",
        "prezzo": 18.0,
        "cat": "Renale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-mycoplasmi-e-ureaplasmi-urine",
        "nome": "RICERCA MYCOPLASMI e UREAPLASMI URINE",
        "prezzo": 20.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "ricerca-neisseria-gonorrhoeae-esame-colturale-tamp",
        "nome": "RICERCA NEISSERIA GONORRHOEAE ESAME COLTURALE TAMP. CERVICALE",
        "prezzo": 15.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-neisseria-gonorrhoeae-esame-colturale-tamp",
        "nome": "RICERCA NEISSERIA GONORRHOEAE ESAME COLTURALE TAMP. VAGINALE",
        "prezzo": 15.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-neisseria-gonorrhoeae-tamp-uretrale",
        "nome": "RICERCA NEISSERIA GONORRHOEAE TAMP. URETRALE",
        "prezzo": 12.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-parassiti-e-uova",
        "nome": "RICERCA PARASSITI E UOVA",
        "prezzo": 15.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-parassiti-e-uova-campione-1",
        "nome": "RICERCA PARASSITI E UOVA CAMPIONE 1",
        "prezzo": 15.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-parassiti-e-uova-campione-2",
        "nome": "RICERCA PARASSITI E UOVA CAMPIONE 2",
        "prezzo": 15.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-parassiti-e-uova-campione-3",
        "nome": "RICERCA PARASSITI E UOVA CAMPIONE 3",
        "prezzo": 15.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-sangue-occulto-feci",
        "nome": "RICERCA SANGUE OCCULTO FECI",
        "prezzo": 4.6,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "ricerca-sangue-occulto-feci-campione-1",
        "nome": "RICERCA SANGUE OCCULTO FECI CAMPIONE 1",
        "prezzo": 3.9,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "ricerca-sangue-occulto-feci-campione-2",
        "nome": "RICERCA SANGUE OCCULTO FECI CAMPIONE 2",
        "prezzo": 3.9,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "ricerca-sangue-occulto-feci-campione-3",
        "nome": "RICERCA SANGUE OCCULTO FECI CAMPIONE 3",
        "prezzo": 3.9,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "ricerca-stafilococco-aureo-nelle-feci",
        "nome": "RICERCA STAFILOCOCCO AUREO NELLE FECI",
        "prezzo": 30.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "ricerca-streptococco-gr-b-streptococcus-agalactiae",
        "nome": "RICERCA STREPTOCOCCO GR. B (Streptococcus agalactiae) TAMPONE RETTALE",
        "prezzo": 8.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-streptococco-gr-b-streptococcus-agalactiae",
        "nome": "RICERCA STREPTOCOCCO GR. B (Streptococcus agalactiae) TAMPONE VAGINALE",
        "prezzo": 8.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-trichomonas-uretrale",
        "nome": "RICERCA TRICHOMONAS URETRALE",
        "prezzo": 12.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ricerca-trichomonas-vaginalis",
        "nome": "RICERCA TRICHOMONAS VAGINALIS",
        "prezzo": 12.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "rickettsia-conori-igg-igm",
        "nome": "RICKETTSIA CONORI IGG - IGM",
        "prezzo": 33.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "rilevazione-ph-vaginale",
        "nome": "RILEVAZIONE pH VAGINALE",
        "prezzo": 10.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "riso-ige-specifiche",
        "nome": "RISO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "rosolia-test-di-avidita-igg",
        "nome": "ROSOLIA - TEST DI AVIDITA' IgG",
        "prezzo": 54.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "infezioni_frequenti"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "rotavirus-ricerca-antigene-nelle-feci",
        "nome": "ROTAVIRUS RICERCA ANTIGENE NELLE FECI",
        "prezzo": 11.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "salice-salix-caprea-ige-specifiche",
        "nome": "SALICE (SALIX CAPREA) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "salmone-ige-specifiche",
        "nome": "SALMONE (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "sardina-ige-specifiche",
        "nome": "SARDINA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "scarafaggio-blatella-germanica-ige-specifiche",
        "nome": "SCARAFAGGIO (BLATELLA GERMANICA) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "scatolo-disbiosi-test",
        "nome": "SCATOLO ( Disbiosi test )",
        "prezzo": 45.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "scotch-test-ricerca-ossiuri",
        "nome": "SCOTCH-TEST RICERCA OSSIURI",
        "prezzo": 12.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "screening-assetto-lipidico",
        "nome": "screening assetto lipidico",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "A digiuno da 12 ore"
    },
    {
        "id": "screening-cardiovascolare-base",
        "nome": "SCREENING CARDIOVASCOLARE BASE",
        "prezzo": 10.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "screening-diabete",
        "nome": "Screening diabete",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "sedano-ige-specifiche",
        "nome": "SEDANO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "segale-secale-cereale-ige-specifiche",
        "nome": "SEGALE (SECALE CEREALE) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "selenio-sierico",
        "nome": "SELENIO SIERICO",
        "prezzo": 23.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "selenio-urine-f-t",
        "nome": "SELENIO URINE F.T.",
        "prezzo": 21.6,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "semi-di-sesamo-ige-specifiche",
        "nome": "SEMI DI SESAMO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "senape-ige-specifiche",
        "nome": "SENAPE (IgE SPECIFICHE)",
        "prezzo": 14.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "serotonina",
        "nome": "SEROTONINA",
        "prezzo": 23.7,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "serotonina-urine-24h",
        "nome": "SEROTONINA URINE 24H",
        "prezzo": 21.9,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "sgombro-ige-specifiche",
        "nome": "SGOMBRO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "shbg-sex-hormone-binding-globulin",
        "nome": "SHBG (SEX HORMONE BINDING GLOBULIN)",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "sideremia",
        "nome": "SIDEREMIA",
        "prezzo": 2.0,
        "cat": "Ematologia",
        "sintomi": [
            "stanchezza",
            "perdita_capelli",
            "anemia"
        ],
        "referto": "48-72h",
        "upsell": "donna-under40"
    },
    {
        "id": "siero-amiloide-a",
        "nome": "SIERO AMILOIDE A",
        "prezzo": 26.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "siero-di-latte-ige-specifiche",
        "nome": "SIERO DI LATTE (IgE SPECIFICHE)",
        "prezzo": 20.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "sindrome-dell-x-fragile",
        "nome": "SINDROME DELL X FRAGILE",
        "prezzo": 220.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "sindrome-di-gilbert",
        "nome": "SINDROME DI GILBERT",
        "prezzo": 300.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "small-dense-ldl-cholesterol-sd-ldl",
        "nome": "SMALL DENSE LDL CHOLESTEROL (SD LDL)",
        "prezzo": 295.0,
        "cat": "Lipidico",
        "sintomi": [
            "controllo_cuore"
        ],
        "referto": "48-72h",
        "upsell": "cardio"
    },
    {
        "id": "smet",
        "nome": "SMET",
        "prezzo": 9.63,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "sodio",
        "nome": "SODIO",
        "prezzo": 4.7,
        "cat": "Elettroliti",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "sodio-urine-24h",
        "nome": "SODIO URINE 24H",
        "prezzo": 3.3,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "sogliola-ige-specifiche",
        "nome": "SOGLIOLA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "soia-ige-specifiche",
        "nome": "SOIA (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "somatomedina-c-igf-1",
        "nome": "SOMATOMEDINA C (IGF-1)",
        "prezzo": 38.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "sordita-congenita-gjb2-cx26-intero-gene",
        "nome": "SORDITA' CONGENITA (GJB2/CX26) - INTERO GENE",
        "prezzo": 190.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "sordita-congenita-gjb2-cx26-principali-mutazioni",
        "nome": "SORDITA' CONGENITA (GJB2/CX26) - PRINCIPALI MUTAZIONI",
        "prezzo": 90.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "sordita-congenita-gjb2-cx30-intero-gene",
        "nome": "SORDITA' CONGENITA (GJB2/CX30) - INTERO GENE",
        "prezzo": 190.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "spermiocoltura-completa",
        "nome": "SPERMIOCOLTURA COMPLETA",
        "prezzo": 50.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "spermiocoltura-germi-comuni",
        "nome": "SPERMIOCOLTURA GERMI COMUNI",
        "prezzo": 22.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "spermiogramma-esame-del-liquido-seminale",
        "nome": "SPERMIOGRAMMA (esame del liquido seminale)",
        "prezzo": 90.0,
        "cat": "Altro",
        "sintomi": [
            "infertilita"
        ],
        "referto": "48-72h",
        "prep": "Astinenza 3-5 giorni"
    },
    {
        "id": "spinaci-ige-specifiche",
        "nome": "SPINACI (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "strep-a-rapid-test",
        "nome": "STREP A Rapid test",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "strep-a-rapid-test",
        "nome": "STREP A Rapid test",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "streptococcus-pneumoniae-ag-urinario",
        "nome": "STREPTOCOCCUS PNEUMONIAE AG URINARIO",
        "prezzo": 98.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "streptozyme",
        "nome": "STREPTOZYME",
        "prezzo": 37.9,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tafano-tabanus-species-ige-specifiche",
        "nome": "TAFANO (TABANUS SPECIES) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "talassemia-beta-screening-23-mutazioni-italiane",
        "nome": "TALASSEMIA BETA - SCREENING 23 MUTAZIONI ITALIANE",
        "prezzo": 140.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "talassemia-beta-intero-gene",
        "nome": "TALASSEMIA BETA- INTERO GENE",
        "prezzo": 190.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tampone-antigenico-sars-cov-2",
        "nome": "TAMPONE ANTIGENICO SARS-COV-2",
        "prezzo": 10.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "tampone-balano-prepuziale",
        "nome": "TAMPONE BALANO - PREPUZIALE",
        "prezzo": 25.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tampone-colturale-endometrio",
        "nome": "TAMPONE COLTURALE ENDOMETRIO",
        "prezzo": 25.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tampone-rapido",
        "nome": "TAMPONE RAPIDO",
        "prezzo": 10.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tampone-rettale-ricerca-gonorrhoeae",
        "nome": "TAMPONE RETTALE - Ricerca Gonorrhoeae",
        "prezzo": 15.5,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tampone-rettale-ricerca-miceti",
        "nome": "TAMPONE RETTALE - Ricerca miceti",
        "prezzo": 8.5,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tampone-rettale-ricerca-salmonella-shigella",
        "nome": "TAMPONE RETTALE - Ricerca Salmonella, Shigella",
        "prezzo": 13.8,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "tampone-uretrale-in-provetta-sterile-con-terreno-d",
        "nome": "TAMPONE URETRALE IN PROVETTA STERILE CON TERRENO DI TRASPORTO STUART",
        "prezzo": 20.0,
        "cat": "Infettivologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tampone-vaginale-real-time-pcr-dna-ricerca-trichom",
        "nome": "TAMPONE VAGINALE REAL-TIME PCR DNA RICERCA TRICHOMONAS VAGINALIS",
        "prezzo": 68.0,
        "cat": "Infiammazione",
        "sintomi": [
            "dolori_articolari",
            "controllo_cuore",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "tamponi-cervico-vaginali-completi",
        "nome": "Tamponi cervico vaginali completi",
        "prezzo": 66.3,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tamponi-vaginali-completi-vaginali",
        "nome": "Tamponi Vaginali (completi vaginali)",
        "prezzo": 49.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tbg-tiroxine-binding-globuline",
        "nome": "TBG (TIROXINE BINDING GLOBULINE)",
        "prezzo": 22.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "telopeptide-ctx-plasmatico",
        "nome": "TELOPEPTIDE (CTX) PLASMATICO",
        "prezzo": 60.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tempo-di-protrombina-pt",
        "nome": "TEMPO DI PROTROMBINA (PT)",
        "prezzo": 4.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tempo-di-tromboplastina-aptt",
        "nome": "TEMPO DI TROMBOPLASTINA (aPTT)",
        "prezzo": 4.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "teofillina",
        "nome": "TEOFILLINA",
        "prezzo": 16.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "test-capacitazione",
        "nome": "Test Capacitazione",
        "prezzo": 250.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "test-conferma-toxoplasma-anticorpi-igg",
        "nome": "TEST CONFERMA TOXOPLASMA ANTICORPI IgG",
        "prezzo": 40.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "infezioni_frequenti"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "test-conferma-toxoplasma-anticorpi-igm",
        "nome": "TEST CONFERMA TOXOPLASMA ANTICORPI IgM",
        "prezzo": 40.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "infezioni_frequenti"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "test-di-capacitazione",
        "nome": "TEST DI CAPACITAZIONE",
        "prezzo": 90.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "test-di-coombs-diretto",
        "nome": "TEST DI COOMBS DIRETTO",
        "prezzo": 15.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "test-di-coombs-indiretto",
        "nome": "TEST DI COOMBS INDIRETTO",
        "prezzo": 10.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "test-di-gravidanza-su-urine",
        "nome": "TEST DI GRAVIDANZA SU URINE",
        "prezzo": 7.5,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "test-di-paternit",
        "nome": "Test di paternità",
        "prezzo": 220.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "test-indagine-di-consanguineit-con-relazione-medic",
        "nome": "Test indagine di consanguineità con relazione medico legale",
        "prezzo": 750.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "testosterone",
        "nome": "TESTOSTERONE",
        "prezzo": 10.0,
        "cat": "Ormoni",
        "sintomi": [
            "perdita_capelli",
            "infertilita",
            "controllo_prostata"
        ],
        "referto": "48-72h",
        "upsell": "uomo-under40"
    },
    {
        "id": "testosterone-biodisponibile",
        "nome": "TESTOSTERONE BIODISPONIBILE",
        "prezzo": 45.0,
        "cat": "Ormoni",
        "sintomi": [
            "perdita_capelli",
            "infertilita",
            "controllo_prostata"
        ],
        "referto": "48-72h",
        "upsell": "uomo-under40"
    },
    {
        "id": "testosterone-libero",
        "nome": "TESTOSTERONE LIBERO",
        "prezzo": 21.0,
        "cat": "Ormoni",
        "sintomi": [
            "perdita_capelli",
            "infertilita",
            "controllo_prostata"
        ],
        "referto": "48-72h",
        "upsell": "uomo-under40"
    },
    {
        "id": "the-ige-specifiche",
        "nome": "THE' (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "tibc-capacita-ferro-legante",
        "nome": "TIBC - CAPACITA' FERRO LEGANTE",
        "prezzo": 7.4,
        "cat": "Ematologia",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tiglio-tiglia-cordata-ige-specifiche",
        "nome": "TIGLIO (TIGLIA CORDATA) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "tiocianati-urine-f-t",
        "nome": "TIOCIANATI URINE F.T.",
        "prezzo": 30.3,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "dolori_articolari",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "tiocianati-urine-i-t",
        "nome": "TIOCIANATI URINE I.T.",
        "prezzo": 30.3,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "dolori_articolari",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "tipizzazione-linfocitaria-completa",
        "nome": "TIPIZZAZIONE LINFOCITARIA COMPLETA",
        "prezzo": 350.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tipizzazione-linfocitaria-singola-t-natural-killer",
        "nome": "Tipizzazione linfocitaria singola T Natural Killer",
        "prezzo": 60.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tipizzazione-thla-b27",
        "nome": "TIPIZZAZIONE THLA-B27",
        "prezzo": 118.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "7-15gg"
    },
    {
        "id": "tireoglobulina",
        "nome": "TIREOGLOBULINA",
        "prezzo": 18.8,
        "cat": "Tiroide",
        "sintomi": [],
        "referto": "48-72h",
        "upsell": "tiroide-plus"
    },
    {
        "id": "tiroxina-t4",
        "nome": "TIROXINA (T4)",
        "prezzo": 10.0,
        "cat": "Tiroide",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tiroxina-libera-ft4",
        "nome": "TIROXINA LIBERA (FT4)",
        "prezzo": 10.0,
        "cat": "Tiroide",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "perdita_capelli",
            "dimagrimento",
            "palpitazioni"
        ],
        "referto": "48-72h",
        "upsell": "donna-over40"
    },
    {
        "id": "titolo-antistafilolisinico-taf",
        "nome": "TITOLO ANTISTAFILOLISINICO (TAF)",
        "prezzo": 35.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "titolo-antistreptolisinico-tas",
        "nome": "TITOLO ANTISTREPTOLISINICO (TAS)",
        "prezzo": 7.9,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tnf-tumor-necrosis-factor",
        "nome": "TNF (TUMOR NECROSIS FACTOR)",
        "prezzo": 85.0,
        "cat": "Infiammazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "toluene-urine-f-t",
        "nome": "TOLUENE URINE F.T.",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "tonno-ige-specifiche",
        "nome": "TONNO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "toxoplasma-test-di-avidita-igg",
        "nome": "TOXOPLASMA - TEST DI AVIDITA' IgG",
        "prezzo": 27.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "gravidanza",
            "infezioni_frequenti"
        ],
        "referto": "48-72h",
        "upsell": "pregravidanza"
    },
    {
        "id": "tpha",
        "nome": "TPHA",
        "prezzo": 5.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "transaminasi-g-o-t-ast",
        "nome": "TRANSAMINASI G.O.T.(AST)",
        "prezzo": 2.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "transaminasi-g-p-t-alt",
        "nome": "TRANSAMINASI G.P.T.(ALT)",
        "prezzo": 2.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "transferrina",
        "nome": "TRANSFERRINA",
        "prezzo": 5.0,
        "cat": "Ematologia",
        "sintomi": [
            "anemia"
        ],
        "referto": "48-72h"
    },
    {
        "id": "transferrina-insatura",
        "nome": "TRANSFERRINA INSATURA",
        "prezzo": 6.0,
        "cat": "Ematologia",
        "sintomi": [
            "anemia"
        ],
        "referto": "48-72h"
    },
    {
        "id": "treponema-pallidum-anticorpi-med-emoa",
        "nome": "TREPONEMA PALLIDUM ANTICORPI MED EMOA",
        "prezzo": 80.0,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "trichomonas-urine",
        "nome": "TRICHOMONAS URINE",
        "prezzo": 10.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "trichomonas-vaginalis-dna",
        "nome": "Trichomonas vaginalis DNA",
        "prezzo": 70.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tricloroetanolo-tce-urine-f-t",
        "nome": "TRICLOROETANOLO (TCE) URINE F.T.",
        "prezzo": 14.3,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "tricloroetanolo-tce-urine-i-t",
        "nome": "TRICLOROETANOLO (TCE) URINE I.T.",
        "prezzo": 14.3,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "trigliceridi",
        "nome": "TRIGLICERIDI",
        "prezzo": 2.5,
        "cat": "Lipidico",
        "sintomi": [
            "aumento_peso",
            "controllo_cuore"
        ],
        "referto": "48-72h",
        "upsell": "cardio",
        "prep": "A digiuno da 12 ore"
    },
    {
        "id": "triiodotironina-libera-ft3",
        "nome": "TRIIODOTIRONINA LIBERA (FT3)",
        "prezzo": 9.0,
        "cat": "Tiroide",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "perdita_capelli",
            "dimagrimento",
            "palpitazioni"
        ],
        "referto": "48-72h",
        "upsell": "donna-over40"
    },
    {
        "id": "triptasi",
        "nome": "TRIPTASI",
        "prezzo": 95.0,
        "cat": "Coagulazione",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "trombofilia-15-mutazioni",
        "nome": "Trombofilia-15 mutazioni",
        "prezzo": 150.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "troponina-t-alta-sensibilita",
        "nome": "TROPONINA T  ALTA SENSIBILITA'",
        "prezzo": 19.4,
        "cat": "Epatico",
        "sintomi": [
            "controllo_cuore",
            "palpitazioni"
        ],
        "referto": "urgente",
        "upsell": "cardio",
        "urgente": true
    },
    {
        "id": "trota-ige-specifiche",
        "nome": "TROTA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "tsh-reflex",
        "nome": "TSH REFLEX",
        "prezzo": 25.0,
        "cat": "Tiroide",
        "sintomi": [
            "aumento_peso",
            "stanchezza",
            "perdita_capelli",
            "dimagrimento",
            "menopausa",
            "gravidanza",
            "palpitazioni",
            "insonnia",
            "infertilita",
            "ansia_stress"
        ],
        "referto": "48h",
        "upsell": "donna-under40"
    },
    {
        "id": "tunel-test-test-di-frammentazione-del-dna-spermati",
        "nome": "TUNEL TEST (Test di frammentazione del DNA spermatico)",
        "prezzo": 180.0,
        "cat": "Genetica/Molecolare",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "tuorlo-ige-specifiche",
        "nome": "TUORLO (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "tyrophagus-putrescentiae-acari-minori-ige-specific",
        "nome": "TYROPHAGUS PUTRESCENTIAE (Acari minori) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "ureaplasma-parvum-dna",
        "nome": "Ureaplasma parvum DNA",
        "prezzo": 75.0,
        "cat": "Renale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ureaplasma-urealyticum-dna",
        "nome": "Ureaplasma urealyticum DNA",
        "prezzo": 70.0,
        "cat": "Renale",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "uricuria-urine-24h",
        "nome": "URICURIA URINE 24H",
        "prezzo": 3.99,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Raccolta urine 24 ore"
    },
    {
        "id": "urina-di-ratto-ige-specifiche",
        "nome": "URINA DI RATTO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "urina-di-topo-ige-specifiche",
        "nome": "URINA DI TOPO (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "uva-ige-specifiche",
        "nome": "UVA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "vanadio-urine-f-t",
        "nome": "VANADIO URINE F.T.",
        "prezzo": 21.6,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "dolori_articolari",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "vanadio-urine-i-t",
        "nome": "VANADIO URINE I.T.",
        "prezzo": 21.6,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "dolori_articolari",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "vaniglia-ige-specifiche",
        "nome": "VANIGLIA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "vdrl",
        "nome": "VDRL",
        "prezzo": 8.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "ves",
        "nome": "VES",
        "prezzo": 4.5,
        "cat": "Infiammazione",
        "sintomi": [
            "dimagrimento",
            "dolori_articolari",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "vespa-polistes-species-ige-specifiche",
        "nome": "VESPA (POLISTES SPECIES) (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Infiammazione",
        "sintomi": [
            "dimagrimento",
            "dolori_articolari",
            "allergie",
            "infezioni_frequenti"
        ],
        "referto": "48-72h"
    },
    {
        "id": "virus-epatite-b-hbv-reflex",
        "nome": "VIRUS EPATITE B (HBV REFLEX)",
        "prezzo": 45.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "virus-epatite-c-immunoblotting-r-i-b-a",
        "nome": "VIRUS EPATITE C IMMUNOBLOTTING (R.I.B.A.)",
        "prezzo": 400.0,
        "cat": "Epatico",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "virus-respiratorio-sincinziale-vrs",
        "nome": "VIRUS RESPIRATORIO SINCINZIALE (VRS)",
        "prezzo": 12.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "visite-di-secondo-controllo-torres",
        "nome": "Visite di secondo controllo Torres",
        "prezzo": 192.93,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "vit-k",
        "nome": "VIT K",
        "prezzo": 323.2,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "vitamina-a",
        "nome": "VITAMINA A",
        "prezzo": 35.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "vitamina-b1",
        "nome": "VITAMINA B1",
        "prezzo": 27.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "vitamina-b12",
        "nome": "VITAMINA B12",
        "prezzo": 15.5,
        "cat": "Vitamina/Minerali",
        "sintomi": [
            "stanchezza",
            "ansia_stress",
            "anemia"
        ],
        "referto": "3-5gg"
    },
    {
        "id": "vitamina-b2-ematica",
        "nome": "Vitamina B2 ematica",
        "prezzo": 18.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "vitamina-b3-nicotinamide",
        "nome": "VITAMINA B3 (NICOTINAMIDE)",
        "prezzo": 235.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "vitamina-b6",
        "nome": "VITAMINA B6",
        "prezzo": 31.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "vitamina-b9",
        "nome": "VITAMINA B9",
        "prezzo": 65.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "vitamina-c",
        "nome": "VITAMINA C",
        "prezzo": 75.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "vitamina-d-25-oh",
        "nome": "VITAMINA D (25 OH)",
        "prezzo": 16.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [
            "menopausa",
            "stanchezza",
            "dolori_articolari",
            "perdita_capelli",
            "ansia_stress",
            "infezioni_frequenti"
        ],
        "referto": "3-5gg",
        "upsell": "donna-under40"
    },
    {
        "id": "vitamina-d-1-25-diidrossi",
        "nome": "VITAMINA D 1-25 DIIDROSSI",
        "prezzo": 92.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [
            "menopausa",
            "stanchezza",
            "dolori_articolari",
            "perdita_capelli",
            "ansia_stress",
            "infezioni_frequenti"
        ],
        "referto": "3-5gg",
        "upsell": "donna-under40"
    },
    {
        "id": "vitamina-d-3-vitamina-d-25-oh-liposolubile",
        "nome": "VITAMINA D 3 - VITAMINA D (25 OH) (LIPOSOLUBILE)",
        "prezzo": 38.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [
            "menopausa",
            "stanchezza",
            "dolori_articolari",
            "perdita_capelli",
            "ansia_stress",
            "infezioni_frequenti"
        ],
        "referto": "3-5gg",
        "upsell": "donna-under40"
    },
    {
        "id": "vitamina-e",
        "nome": "VITAMINA E",
        "prezzo": 30.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "vitamina-h",
        "nome": "VITAMINA H",
        "prezzo": 100.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "vitamina-k",
        "nome": "VITAMINA K",
        "prezzo": 324.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [],
        "referto": "3-5gg"
    },
    {
        "id": "von-willebrand-attivita",
        "nome": "VON WILLEBRAND ATTIVITA'",
        "prezzo": 25.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "vongola-ige-specifiche",
        "nome": "VONGOLA (IgE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "weil-felix-anticorpi-anti-rickettsia-proteus",
        "nome": "WEIL-FELIX (ANTICORPI ANTI-RICKETTSIA/PROTEUS)",
        "prezzo": 18.5,
        "cat": "Autoimmunità",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "widal-wright",
        "nome": "WIDAL-WRIGHT",
        "prezzo": 14.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "x-fragile-ricerca-gene-fmr1-fraxa",
        "nome": "X Fragile - RICERCA gene FMR1 (FRAXA)",
        "prezzo": 90.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "x-fragile-gene-fmr1-livello-ii",
        "nome": "X Fragile gene FMR1 (Livello II)",
        "prezzo": 170.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "x-fragile-fraxa",
        "nome": "X-FRAGILE (FRAXA)",
        "prezzo": 100.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "xilosio",
        "nome": "XILOSIO",
        "prezzo": 53.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "yersinia-nelle-feci",
        "nome": "YERSINIA NELLE FECI",
        "prezzo": 18.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "zanzara-aedes-communis-ige-specifiche",
        "nome": "ZANZARA (AEDES COMMUNIS) (IgE SPECIFICHE)",
        "prezzo": 12.5,
        "cat": "Autoimmunità",
        "sintomi": [
            "allergie"
        ],
        "referto": "48-72h"
    },
    {
        "id": "zinco",
        "nome": "ZINCO",
        "prezzo": 22.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [
            "perdita_capelli"
        ],
        "referto": "48-72h"
    },
    {
        "id": "zinco-urine-f-t",
        "nome": "ZINCO URINE F.T.",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "perdita_capelli",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "zinco-urine-i-t",
        "nome": "ZINCO URINE I.T.",
        "prezzo": 20.0,
        "cat": "Renale",
        "sintomi": [
            "gravidanza",
            "perdita_capelli",
            "controllo_reni"
        ],
        "referto": "24h",
        "upsell": "base",
        "prep": "Urine del mattino, mitto intermedio"
    },
    {
        "id": "zincoprotoporfirina",
        "nome": "ZINCOPROTOPORFIRINA",
        "prezzo": 55.0,
        "cat": "Vitamina/Minerali",
        "sintomi": [
            "perdita_capelli"
        ],
        "referto": "48-72h"
    },
    {
        "id": "znt8-abs",
        "nome": "ZnT8 Abs",
        "prezzo": 120.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "zntb-a",
        "nome": "ZNTB A",
        "prezzo": 120.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "zonulina-fecale",
        "nome": "ZONULINA FECALE",
        "prezzo": 175.0,
        "cat": "Fecale",
        "sintomi": [],
        "referto": "48-72h",
        "prep": "Campione feci fresco"
    },
    {
        "id": "zonulina-sierica",
        "nome": "ZONULINA SIERICA",
        "prezzo": 95.5,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "zucca-ihe-specifiche",
        "nome": "ZUCCA (IhE SPECIFICHE)",
        "prezzo": 19.0,
        "cat": "Altro",
        "sintomi": [],
        "referto": "48-72h"
    },
    {
        "id": "nipt-fetal-dna-standard",
        "nome": "Fetal DNA Test Standard (NIPT)",
        "prezzo": 290.0,
        "cat": "Genetica",
        "sintomi": ["gravidanza"],
        "referto": "7-10gg",
        "url": "pages/genetica.html",
        "descrizione": "Test prenatale non invasivo per screening trisomie 21, 18, 13"
    },
    {
        "id": "nipt-fetal-dna-plus",
        "nome": "Fetal DNA Test Plus (NIPT Avanzato)",
        "prezzo": 390.0,
        "cat": "Genetica",
        "sintomi": ["gravidanza"],
        "referto": "7-10gg",
        "url": "pages/genetica.html",
        "descrizione": "NIPT esteso con microdelezioni e aneuploidie sessuali"
    },
    {
        "id": "prenatal-advance",
        "nome": "PrenatalAdvance (NIPT Premium)",
        "prezzo": 690.0,
        "cat": "Genetica",
        "sintomi": ["gravidanza"],
        "referto": "7-10gg",
        "url": "pages/genetica.html",
        "descrizione": "Test prenatale più completo: trisomie + microdelezioni + 50 sindromi genetiche"
    },
    {
        "id": "rh-fetale",
        "nome": "Determinazione Rh Fetale",
        "prezzo": 200.0,
        "cat": "Genetica",
        "sintomi": ["gravidanza"],
        "referto": "5-7gg",
        "url": "pages/genetica.html",
        "descrizione": "Determinazione del fattore Rh fetale da sangue materno"
    },
    {
        "id": "carrier-screening-base",
        "nome": "Carrier Screening Base",
        "prezzo": 350.0,
        "cat": "Genetica",
        "sintomi": ["infertilita", "gravidanza"],
        "referto": "15-20gg",
        "url": "pages/genetica.html",
        "descrizione": "Pannello portatori per fibrosi cistica, talassemie e altre malattie recessive"
    },
    {
        "id": "carrier-screening-plus",
        "nome": "Carrier Screening Plus (300+ geni)",
        "prezzo": 490.0,
        "cat": "Genetica",
        "sintomi": ["infertilita", "gravidanza"],
        "referto": "15-20gg",
        "url": "pages/genetica.html",
        "descrizione": "Screening portatori esteso su oltre 300 geni per malattie recessive"
    },
    {
        "id": "brca-plus",
        "nome": "BRCA Plus (Oncogenetica)",
        "prezzo": 590.0,
        "cat": "Genetica",
        "sintomi": [],
        "referto": "20-25gg",
        "url": "pages/genetica.html",
        "descrizione": "Test mutazioni BRCA1/BRCA2 per rischio tumori seno e ovaio"
    },
    {
        "id": "onco-panel-hereditary",
        "nome": "Pannello Oncogenetico Ereditario",
        "prezzo": 990.0,
        "cat": "Genetica",
        "sintomi": [],
        "referto": "25-30gg",
        "url": "pages/genetica.html",
        "descrizione": "Analisi 30+ geni per tumori ereditari (seno, ovaio, colon, prostata)"
    },
    {
        "id": "endotest-endometriosi",
        "nome": "EndoTest (Endometriosi)",
        "prezzo": 990.0,
        "cat": "Genetica",
        "sintomi": ["infertilita"],
        "referto": "15-20gg",
        "url": "pages/genetica.html",
        "descrizione": "Test salivare per diagnosi endometriosi basato su microRNA"
    },
    {
        "id": "emma-test",
        "nome": "EMMA Test (Microbioma Endometriale)",
        "prezzo": 490.0,
        "cat": "Genetica",
        "sintomi": ["infertilita"],
        "referto": "10-15gg",
        "url": "pages/genetica.html",
        "descrizione": "Analisi microbiota endometriale per ottimizzare transfer embrionario"
    },
    {
        "id": "era-test",
        "nome": "ERA Test (Recettività Endometriale)",
        "prezzo": 730.0,
        "cat": "Genetica",
        "sintomi": ["infertilita"],
        "referto": "10-15gg",
        "url": "pages/genetica.html",
        "descrizione": "Test per identificare finestra impianto personalizzata in PMA"
    },
    {
        "id": "alice-test",
        "nome": "ALICE Test (Endometrite Cronica)",
        "prezzo": 350.0,
        "cat": "Genetica",
        "sintomi": ["infertilita"],
        "referto": "10-15gg",
        "url": "pages/genetica.html",
        "descrizione": "Diagnosi endometrite cronica per fallimenti impianto"
    },
    {
        "id": "trio-test-emma-era-alice",
        "nome": "EndomeTRIO (EMMA + ERA + ALICE)",
        "prezzo": 1290.0,
        "cat": "Genetica",
        "sintomi": ["infertilita"],
        "referto": "15-20gg",
        "url": "pages/genetica.html",
        "descrizione": "Pacchetto completo per studio endometriale in PMA"
    },
    {
        "id": "nutrigenetica-base",
        "nome": "Nutrigenetica Base",
        "prezzo": 195.0,
        "cat": "Genetica",
        "sintomi": ["aumento_peso"],
        "referto": "15-20gg",
        "url": "pages/genetica.html",
        "descrizione": "Profilo genetico per metabolismo nutrienti e dieta personalizzata"
    },
    {
        "id": "nutrigenetica-plus",
        "nome": "Nutrigenetica Plus (50+ varianti)",
        "prezzo": 350.0,
        "cat": "Genetica",
        "sintomi": ["aumento_peso"],
        "referto": "15-20gg",
        "url": "pages/genetica.html",
        "descrizione": "Analisi completa 50+ varianti per nutrizione personalizzata"
    },
    {
        "id": "cariotipo-sangue",
        "nome": "Cariotipo (Sangue Periferico)",
        "prezzo": 230.0,
        "cat": "Genetica",
        "sintomi": ["infertilita"],
        "referto": "15-20gg",
        "url": "pages/genetica.html",
        "descrizione": "Analisi cromosomica per infertilità e aborti ricorrenti"
    },
    {
        "id": "pannello-trombofilia",
        "nome": "Pannello Trombofilia Genetica",
        "prezzo": 180.0,
        "cat": "Genetica",
        "sintomi": ["gravidanza", "infertilita"],
        "referto": "7-10gg",
        "url": "pages/genetica.html",
        "descrizione": "Mutazioni Fattore V Leiden, Protrombina, MTHFR"
    },
    {
        "id": "celiachia-genetica",
        "nome": "Predisposizione Genetica Celiachia",
        "prezzo": 120.0,
        "cat": "Genetica",
        "sintomi": ["problemi_digestivi"],
        "referto": "7-10gg",
        "url": "pages/genetica.html",
        "descrizione": "Analisi HLA-DQ2/DQ8 per predisposizione celiachia"
    }
];

  // =============================================
  // 3. CONFIGURAZIONE E LOGICA
  // =============================================
  const config = {
    "urgenza": {
        "esami": [
            "beta-hcg",
            "troponina",
            "d-dimero",
            "procalcitonina",
            "lattato",
            "ammoniemia"
        ],
        "cta": {
            "testo": "⚡ Risultato in giornata",
            "messaggio": "Questo esame ha priorità urgente. Vieni in laboratorio senza appuntamento."
        }
    },
    "specialisti": {
        "cardiologia": {
            "nome": "Dr. Tonino Bullitta",
            "ruolo": "Cardiologo",
            "link": "/equipe/tonino-bullitta.html"
        },
        "endocrinologia": {
            "nome": "Dr. Francesco Tolu",
            "ruolo": "Endocrinologo - Resp. Slim Care",
            "link": "/equipe/francesco-tolu.html"
        },
        "ginecologia": {
            "nome": "Prof. Salvatore Dessole",
            "ruolo": "Direttore Sanitario - Ginecologo",
            "link": "/equipe/salvatore-dessole.html"
        },
        "laboratorio": {
            "nome": "Bio-Clinic Lab",
            "ruolo": "Laboratorio Analisi",
            "link": "/pages/laboratorio.html"
        }
    },
    "contatti": {
        "telefono": "079 956 1332",
        "email": "gestione@bio-clinic.it",
        "indirizzo": "Via Renzo Mossa, 23 - 07100 Sassari",
        "orari": {
            "feriali": "07:00-21:00",
            "sabato": "08:00-14:00"
        }
    },
    "prep_icons": {
        "digiuno": "🍽️",
        "urine": "🧪",
        "feci": "🔬",
        "mattino": "🌅",
        "riposo": "😴"
    }
};

  // =============================================
  // 4. MAPPA SINTOMI -> LABELS
  // =============================================
  const sintomiLabels = {
    "stanchezza": "Stanchezza cronica",
    "perdita_capelli": "Perdita di capelli",
    "aumento_peso": "Aumento di peso",
    "dimagrimento": "Perdita di peso involontaria",
    "palpitazioni": "Palpitazioni",
    "insonnia": "Disturbi del sonno",
    "ansia_stress": "Ansia e stress",
    "dolori_articolari": "Dolori articolari",
    "problemi_digestivi": "Problemi digestivi",
    "infertilita": "Difficoltà a concepire",
    "menopausa": "Sintomi menopausa",
    "gravidanza": "Gravidanza",
    "infezioni_frequenti": "Infezioni frequenti",
    "controllo_prostata": "Controllo prostata",
    "controllo_cuore": "Controllo cardiovascolare",
    "controllo_fegato": "Controllo fegato",
    "controllo_reni": "Controllo reni",
    "allergie": "Allergie",
    "anemia": "Anemia"
};

  // =============================================
  // 5. INDICI PER RICERCA VELOCE
  // =============================================
  
  // Indice per categoria
  const byCategory = {};
  listino.forEach(e => {
    if (!byCategory[e.cat]) byCategory[e.cat] = [];
    byCategory[e.cat].push(e);
  });

  // Indice per sintomo
  const bySymptom = {};
  listino.forEach(e => {
    (e.sintomi || []).forEach(s => {
      if (!bySymptom[s]) bySymptom[s] = [];
      bySymptom[s].push(e);
    });
  });

  // Indice per upsell pack
  const byUpsell = {};
  listino.forEach(e => {
    if (e.upsell) {
      if (!byUpsell[e.upsell]) byUpsell[e.upsell] = [];
      byUpsell[e.upsell].push(e);
    }
  });

  // =============================================
  // 6. MOTORE DI RICERCA INTELLIGENTE
  // =============================================
  
  /**
   * Ricerca full-text con fuzzy matching
   * @param {string} query - Termine di ricerca
   * @param {object} options - Opzioni di ricerca
   * @returns {object} Risultati raggruppati
   */
  function search(query, options = {}) {
    const q = query.toLowerCase().trim();
    if (q.length < 2) return { esami: [], pacchetti: [], suggerimenti: [] };

    const maxResults = options.maxResults || 20;
    const results = {
      esami: [],
      pacchetti: [],
      suggerimenti: [],
      packSuggerito: null
    };

    // 1. Cerca nei pacchetti PRIMA (PACK-FIRST!)
    pacchetti.forEach(p => {
      const score = calculateRelevance(q, [
        p.nome, 
        p.descrizione, 
        ...p.tags,
        ...(p.target || [])
      ]);
      if (score > 0) {
        results.pacchetti.push({ ...p, _score: score });
      }
    });

    // 2. Cerca nei sintomi
    Object.keys(sintomiLabels).forEach(symptom => {
      const label = sintomiLabels[symptom].toLowerCase();
      if (label.includes(q) || symptom.includes(q)) {
        results.suggerimenti.push({
          tipo: 'sintomo',
          id: symptom,
          label: sintomiLabels[symptom],
          esami: bySymptom[symptom] || []
        });
      }
    });

    // 3. Cerca negli esami
    listino.forEach(e => {
      const score = calculateRelevance(q, [
        e.nome,
        e.cat,
        ...(e.sintomi || []).map(s => sintomiLabels[s] || s)
      ]);
      if (score > 0) {
        results.esami.push({ ...e, _score: score });
      }
    });

    // Ordina per rilevanza
    results.esami.sort((a, b) => b._score - a._score);
    results.pacchetti.sort((a, b) => b._score - a._score);

    // Limita risultati
    results.esami = results.esami.slice(0, maxResults);

    // 4. LOGICA PACK-FIRST: Se c'è un esame con upsell, suggerisci il pack
    if (results.esami.length > 0 && results.esami[0].upsell) {
      const suggestedPackId = results.esami[0].upsell;
      results.packSuggerito = pacchetti.find(p => p.id === suggestedPackId);
    }

    return results;
  }

  /**
   * Calcola rilevanza fuzzy
   */
  function calculateRelevance(query, fields) {
    let score = 0;
    const q = query.toLowerCase();
    
    fields.forEach((field, idx) => {
      if (!field) return;
      const f = field.toLowerCase();
      
      // Match esatto
      if (f === q) score += 100;
      // Inizia con
      else if (f.startsWith(q)) score += 50;
      // Contiene
      else if (f.includes(q)) score += 25;
      // Fuzzy (ogni parola)
      else {
        const words = q.split(/\s+/);
        words.forEach(w => {
          if (f.includes(w)) score += 10;
        });
      }
    });

    return score;
  }

  // =============================================
  // 7. SUGGERITORI INTELLIGENTI
  // =============================================

  /**
   * Suggerisci pack basato su età e sesso
   */
  function suggerisciPack(eta, sesso) {
    const s = sesso.toLowerCase();
    const e = parseInt(eta);

    if (s === 'donna' || s === 'f') {
      return e >= 40 
        ? pacchetti.find(p => p.id === 'donna-over40')
        : pacchetti.find(p => p.id === 'donna-under40');
    }
    
    if (s === 'uomo' || s === 'm') {
      return e >= 40 
        ? pacchetti.find(p => p.id === 'uomo-over40')
        : pacchetti.find(p => p.id === 'uomo-under40');
    }

    return pacchetti.find(p => p.id === 'base');
  }

  /**
   * Suggerisci esami per sintomo
   */
  function esamiPerSintomo(sintomo) {
    const s = sintomo.toLowerCase().replace(/\s+/g, '_');
    return bySymptom[s] || [];
  }

  /**
   * Ottieni esami di una categoria
   */
  function esamiPerCategoria(categoria) {
    return byCategory[categoria] || [];
  }

  /**
   * Cerca esami urgenti
   */
  function isUrgente(esameId) {
    return config.urgenza.esami.some(u => esameId.includes(u));
  }

  /**
   * Ottieni pack correlati a un esame
   */
  function packPerEsame(esame) {
    if (!esame.upsell) return null;
    return pacchetti.find(p => p.id === esame.upsell);
  }

  // =============================================
  // 8. STATISTICHE E METADATA
  // =============================================
  
  const stats = {
    totaleEsami: listino.length,
    totalePacchetti: pacchetti.length,
    categorie: Object.keys(byCategory).length,
    sintomiMappati: Object.keys(bySymptom).length,
    esamiConUpsell: listino.filter(e => e.upsell).length,
    prezzoMin: Math.min(...listino.map(e => e.prezzo)),
    prezzoMax: Math.max(...listino.map(e => e.prezzo)),
    prezzoPacchettiRange: {
      min: Math.min(...pacchetti.map(p => p.prezzo)),
      max: Math.max(...pacchetti.map(p => p.prezzo))
    }
  };

// =============================================
  // 10. MEDICI CON PUBBLICAZIONI (E-E-A-T)
  // =============================================
  
  const physiciansWithPublications = [
    {
      slug: 'salvatore-dessole',
      name: 'Prof. Salvatore Dessole',
      specialty: 'Ginecologia e Ostetricia',
      citations: 5628,
      publications: [
        {
          title: 'Sonovaginography is a new technique for assessing rectovaginal endometriosis',
          url: 'https://pubmed.ncbi.nlm.nih.gov/12749448/',
          year: 2003,
          journal: 'Fertility and Sterility'
        },
        {
          title: 'Postpartum ovarian vein thrombosis: an unpredictable event',
          url: 'https://pubmed.ncbi.nlm.nih.gov/12592429/',
          year: 2003,
          journal: 'Archives of Gynecology and Obstetrics'
        }
      ],
      knowsAbout: ['dolore pelvico', 'menopausa', 'infertilità', 'endometriosi', 'gravidanza a rischio']
    },
    {
      slug: 'francesco-bussu',
      name: 'Prof. Francesco Bussu',
      specialty: 'Otorinolaringoiatria',
      citations: 3500,
      publications: [
        {
          title: 'Management of nasal vestibule carcinomas: recommendations by the Italian Society of Otorhinolaryngology',
          url: 'https://pubmed.ncbi.nlm.nih.gov/38420717/',
          year: 2024,
          journal: 'Acta Otorhinolaryngologica Italica'
        },
        {
          title: 'Transoral Robotic Surgery for Salvage of Irradiated Oropharyngeal Cancer',
          url: 'https://pubmed.ncbi.nlm.nih.gov/41003122/',
          year: 2025,
          journal: 'Journal of Clinical Medicine'
        }
      ],
      knowsAbout: ['mal di gola', 'raucedine', 'difficoltà a deglutire', 'acufeni', 'apnee notturne']
    },
    {
      slug: 'pietro-pirina',
      name: 'Prof. Pietro Pirina',
      specialty: 'Pneumologia',
      citations: 6866,
      publications: [
        {
          title: 'Glutathione Peroxidase in Stable Chronic Obstructive Pulmonary Disease',
          url: 'https://pubmed.ncbi.nlm.nih.gov/34829616/',
          year: 2021,
          journal: 'Antioxidants'
        },
        {
          title: 'Assessment of peak inspiratory flow in patients with COPD',
          url: 'https://pubmed.ncbi.nlm.nih.gov/40998461/',
          year: 2025,
          journal: 'BMC Pulmonary Medicine'
        }
      ],
      knowsAbout: ['tosse persistente', 'asma', 'BPCO', 'affanno', 'apnea del sonno']
    },
    {
      slug: 'antonio-solinas',
      name: 'Prof. Antonio Solinas',
      specialty: 'Medicina Interna - Epatologia',
      citations: 1200,
      publications: [
        {
          title: 'A prognostic marker and therapeutic target for liver cancer',
          url: 'https://pubmed.ncbi.nlm.nih.gov/27618225/',
          year: 2016,
          journal: 'World Journal of Hepatology'
        },
        {
          title: 'Cognitive dysfunction and hepatitis C virus infection',
          url: 'https://pmc.ncbi.nlm.nih.gov/articles/PMC4419096/',
          year: 2015,
          journal: 'World Journal of Hepatology'
        }
      ],
      knowsAbout: ['epatite', 'cirrosi', 'ittero', 'transaminasi alte', 'dolore addominale']
    },
    {
      slug: 'marco-petrillo',
      name: 'Prof. Marco Petrillo',
      specialty: 'Ginecologia Oncologica',
      citations: 2100,
      publications: [
        {
          title: 'The role of surgery in platinum-resistant ovarian cancer',
          url: 'https://pubmed.ncbi.nlm.nih.gov/33607247/',
          year: 2021,
          journal: 'European Journal of Surgical Oncology'
        },
        {
          title: 'Pharmacokinetics of cisplatin during HIPEC',
          url: 'https://pubmed.ncbi.nlm.nih.gov/31074245/',
          year: 2019,
          journal: 'Gynecologic Oncology'
        }
      ],
      knowsAbout: ['tumore ovarico', 'endometriosi', 'infertilità', 'dolore pelvico']
    }
  ];

  // Funzione per ottenere medici con pubblicazioni
  function getPhysiciansWithPublications() {
    return physiciansWithPublications;
  }

  // Funzione per cercare medici per sintomo
  function findPhysicianBySymptom(symptom) {
    const s = symptom.toLowerCase();
    return physiciansWithPublications.filter(p => 
      p.knowsAbout.some(k => k.toLowerCase().includes(s))
    );
  }

  // =============================================
  // 11. PROCEDURE DIAGNOSTICHE SPECIALISTICHE
  // =============================================
  
  const procedureDiagnostiche = [
    {
      id: 'isteroscopia',
      nome: 'Isteroscopia Diagnostica',
      categoria: 'ginecologia',
      url: 'pages/isteroscopia.html',
      bookingType: 'direct',
      descrizione: 'Visualizzazione diretta della cavità uterina per diagnosi di polipi, miomi, malformazioni e aderenze.',
      durata: '15-20 minuti',
      preparazione: 'Ciclo mestruale terminato, digiuno non necessario',
      medico: {
        nome: 'Prof. Salvatore Dessole',
        slug: 'salvatore-dessole'
      },
      keywords: ['isteroscopia', 'cavità uterina', 'polipi', 'miomi', 'infertilità', 'pma', 'fertilità'],
      correlati: ['isterosalpingografia', 'pma-fertilita', 'visita-ginecologica']
    },
    {
      id: 'isterosalpingografia',
      nome: 'Isterosalpingografia (HSG)',
      categoria: 'ginecologia',
      url: 'pages/isterosalpingografia.html',
      bookingType: 'direct',
      descrizione: 'Esame radiologico per valutare la pervietà delle tube di Falloppio e la morfologia uterina.',
      durata: '20-30 minuti',
      preparazione: 'Post-ciclo, digiuno da 4 ore',
      medico: {
        nome: 'Prof. Salvatore Dessole',
        slug: 'salvatore-dessole'
      },
      keywords: ['isterosalpingografia', 'hsg', 'tube', 'pervietà tubarica', 'infertilità', 'pma', 'fertilità', 'sterilità'],
      correlati: ['isteroscopia', 'pma-fertilita', 'visita-ginecologica']
    }
  ];

  // Funzione per ottenere procedure diagnostiche
  function getProcedureDiagnostiche() {
    return procedureDiagnostiche;
  }

  // Funzione per cercare procedure per keyword
  function searchProcedure(query) {
    const q = query.toLowerCase().trim();
    return procedureDiagnostiche.filter(p => 
      p.nome.toLowerCase().includes(q) ||
      p.keywords.some(k => k.includes(q)) ||
      p.descrizione.toLowerCase().includes(q)
    );
  }

  // Funzione per ottenere procedura per ID
  function getProcedura(id) {
    return procedureDiagnostiche.find(p => p.id === id);
  }

  // =============================================
  // 9. API PUBBLICA
  // =============================================
  
  return {
    // Dati
    pacchetti,
    listino,
    config,
    sintomiLabels,
    stats,
    physiciansWithPublications,
    procedureDiagnostiche,
    
    // Indici
    byCategory,
    bySymptom,
    byUpsell,
    
    // Metodi
    search,
    suggerisciPack,
    esamiPerSintomo,
    esamiPerCategoria,
    isUrgente,
    packPerEsame,
    getPhysiciansWithPublications,
    findPhysicianBySymptom,
    getProcedureDiagnostiche,
    searchProcedure,
    
    // Utilities
    getEsame: (id) => listino.find(e => e.id === id),
    getPack: (id) => pacchetti.find(p => p.id === id),
    getCategorie: () => Object.keys(byCategory),
    getSintomi: () => Object.keys(sintomiLabels),
    getPhysician: (slug) => physiciansWithPublications.find(p => p.slug === slug),
    getProcedura,
    
    // Versione
    version: '3.2.0',
    generated: '2026-01-31T12:00:00'
  };

})();

// Export per moduli ES6
if (typeof module !== 'undefined' && module.exports) {
  module.exports = BioClinicDB;
}

// Alias globali
window.db = BioClinicDB;
window.BioClinicDB = BioClinicDB;

console.log('[BioClinicDB] 📊 Database caricato:', BioClinicDB.stats);
